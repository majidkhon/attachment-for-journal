module

public import Mathlib

/-!
# General facts on Loday-biderivations of right Leibniz algebras

This file checks the general (basis-free) statements of Section 2 of the revised
manuscript.  A right Leibniz algebra is a module `L` over a commutative ring `R`
with a bilinear product `br` satisfying
`[[x,y],z] = [[x,z],y] + [x,[y,z]]`.  No finiteness assumption is made, so the
results apply verbatim to the infinite-dimensional algebras of Section 8.

* `LodayBider.bracket_rightLeibniz` : the product on pairs is right Leibniz.
* `LodayBider.IsLBider.bracket`     : `LBider(L)` is closed under the product.
* `LodayBider.theta_isLBider`       : `Θ_a = (-R_a, L_a)` is a Loday-biderivation.
* `LodayBider.theta_bracket_theta`  : `a ↦ Θ_a` is a homomorphism.
* `LodayBider.bracket_theta`, `LodayBider.theta_bracket` : `ILBider(L)` is an ideal.
* `LodayBider.compat_iff`           : compatibility ⇔ `(d - D)(L) ⊆ Ann_r(L)`.
* `LodayBider.theta_eq_zero_iff`    : `ker ι_L = Ann(L)`.
* `LodayBider.allInner_iff`         : criterion for all Loday-biderivations to be inner.
-/

@[expose] public section

namespace LodayBider

variable {R L : Type*} [CommRing R] [AddCommGroup L] [Module R L]

/-- The right Leibniz identity `[[x,y],z] = [[x,z],y] + [x,[y,z]]`. -/
def IsRightLeibniz (br : L →ₗ[R] L →ₗ[R] L) : Prop :=
  ∀ x y z, br (br x y) z = br (br x z) y + br x (br y z)

/-- `d` is a derivation. -/
def IsDer (br : L →ₗ[R] L →ₗ[R] L) (d : Module.End R L) : Prop :=
  ∀ x y, d (br x y) = br (d x) y + br x (d y)

/-- `D` is a Loday-antiderivation: `D[x,y] = [D x, y] - [D y, x]`. -/
def IsADer (br : L →ₗ[R] L →ₗ[R] L) (D : Module.End R L) : Prop :=
  ∀ x y, D (br x y) = br (D x) y - br (D y) x

/-- `(d, D)` is a Loday-biderivation. -/
def IsLBider (br : L →ₗ[R] L →ₗ[R] L) (p : Module.End R L × Module.End R L) : Prop :=
  IsDer br p.1 ∧ IsADer br p.2 ∧ ∀ x y, br x (p.1 y) = br x (p.2 y)

/-- The product `[(d,D),(d',D')] = (dd' - d'd, Dd' - d'D)`. -/
def bracket (p q : Module.End R L × Module.End R L) : Module.End R L × Module.End R L :=
  (p.1 * q.1 - q.1 * p.1, p.2 * q.1 - q.1 * p.2)

/-- The inner Loday-biderivation `Θ_a = (-R_a, L_a)`. -/
def theta (br : L →ₗ[R] L →ₗ[R] L) (a : L) : Module.End R L × Module.End R L :=
  (-(br.flip a), br a)

/-- The right annihilator `Ann_r(L) = {y | [L, y] = 0}`. -/
def annR (br : L →ₗ[R] L →ₗ[R] L) : Set L := {y | ∀ x, br x y = 0}

/-- The (two-sided) annihilator `Ann(L) = Ann_ℓ(L) ∩ Ann_r(L)`. -/
def ann (br : L →ₗ[R] L →ₗ[R] L) : Set L := {a | (∀ x, br a x = 0) ∧ ∀ x, br x a = 0}

variable {br : L →ₗ[R] L →ₗ[R] L}

/-- The product on pairs of endomorphisms satisfies the right Leibniz identity
(no hypothesis on the pairs is needed). -/
theorem bracket_rightLeibniz (p q r : Module.End R L × Module.End R L) :
    bracket (bracket p q) r = bracket (bracket p r) q + bracket p (bracket q r) := by
  obtain ⟨a, A⟩ := p; obtain ⟨b, B⟩ := q; obtain ⟨c, C⟩ := r
  simp only [bracket, Prod.mk_add_mk, Prod.mk.injEq]
  constructor <;> noncomm_ring

/-- In a right Leibniz algebra, `[x, [a,y] + [y,a]] = 0`, i.e. `Leib(L) ⊆ Ann_r(L)`. -/
theorem br_sym_mem_annR (hL : IsRightLeibniz br) (a y : L) :
    br a y + br y a ∈ annR br := by
  intro x
  have h1 := hL x a y
  have h2 := hL x y a
  rw [map_add]
  have e : br x (br a y) + br x (br y a) =
      (br (br x y) a + br x (br a y) + (br (br x a) y + br x (br y a))) -
        (br (br x a) y + br (br x y) a) := by abel
  rw [e, ← h1, ← h2, sub_self]

/-- Every derivation maps `Ann_r(L)` into itself. -/
theorem IsDer.map_annR {d : Module.End R L} (hd : IsDer br d) {u : L} (hu : u ∈ annR br) :
    d u ∈ annR br := by
  intro x
  have := hd x u
  rw [hu x, hu (d x), map_zero, zero_add] at this
  exact this.symm

/-- `LBider(L)` is closed under the product. -/
theorem IsLBider.bracket {p q : Module.End R L × Module.End R L}
    (hp : IsLBider br p) (hq : IsLBider br q) : IsLBider br (bracket p q) := by
  obtain ⟨hd, hD, hc⟩ := hp
  obtain ⟨hd', hD', hc'⟩ := hq
  unfold IsDer at hd hd'
  unfold IsADer at hD hD'
  refine ⟨?_, ?_, ?_⟩
  · intro x y
    simp only [LodayBider.bracket, LinearMap.sub_apply, Module.End.mul_apply, map_sub]
    simp only [hd, hd', map_add]
    abel
  · intro x y
    simp only [LodayBider.bracket, LinearMap.sub_apply, Module.End.mul_apply, map_sub]
    simp only [hd', hD, map_add, map_sub]
    abel
  · intro x y
    simp only [LodayBider.bracket, LinearMap.sub_apply, Module.End.mul_apply, map_sub]
    -- `u = (d - D) y` lies in `Ann_r`, hence so does `d' u`
    have hu : p.1 y - p.2 y ∈ annR br := by
      intro z; rw [map_sub, hc z y, sub_self]
    have hdu := IsDer.map_annR (d := q.1) hd' hu x
    rw [map_sub, map_sub, sub_eq_zero] at hdu
    rw [hc x (q.1 y), hdu]

/-- `Θ_a` is a Loday-biderivation. -/
theorem theta_isLBider (hL : IsRightLeibniz br) (a : L) : IsLBider br (theta br a) := by
  refine ⟨?_, ?_, ?_⟩
  · intro x y
    simp only [theta, LinearMap.neg_apply, LinearMap.flip_apply, map_neg,
      LinearMap.neg_apply]
    rw [hL x y a]; abel
  · intro x y
    simp only [theta]
    rw [hL a x y]; abel
  · intro x y
    simp only [theta, LinearMap.neg_apply, LinearMap.flip_apply, map_neg]
    have := br_sym_mem_annR hL a y x
    rw [map_add] at this
    linear_combination (norm := skip) -this
    abel

/-- `ι_L : a ↦ Θ_a` is a homomorphism of Leibniz algebras. -/
theorem theta_bracket_theta (hL : IsRightLeibniz br) (a b : L) :
    bracket (theta br a) (theta br b) = theta br (br a b) := by
  simp only [bracket, theta, Prod.mk.injEq]
  constructor
  · ext x
    simp only [LinearMap.sub_apply, Module.End.mul_apply, LinearMap.neg_apply,
      LinearMap.flip_apply, map_neg, neg_neg]
    rw [hL x a b]; abel
  · ext x
    simp only [LinearMap.sub_apply, Module.End.mul_apply, LinearMap.neg_apply,
      LinearMap.flip_apply, map_neg]
    rw [hL a x b]; abel

/-- `ILBider(L)` is a right ideal: `[(d,D), Θ_a] = Θ_{D(a)}`. -/
theorem bracket_theta {p : Module.End R L × Module.End R L} (hp : IsLBider br p) (a : L) :
    bracket p (theta br a) = theta br (p.2 a) := by
  obtain ⟨hd, hD, hc⟩ := hp
  simp only [bracket, theta, Prod.mk.injEq]
  constructor
  · ext x
    simp only [LinearMap.sub_apply, Module.End.mul_apply, LinearMap.neg_apply,
      LinearMap.flip_apply, map_neg]
    rw [hd, hc]; abel
  · ext x
    simp only [LinearMap.sub_apply, Module.End.mul_apply, LinearMap.neg_apply,
      LinearMap.flip_apply, map_neg]
    rw [hD]; abel

/-- `ILBider(L)` is a left ideal: `[Θ_a, (d,D)] = -Θ_{d(a)}`. -/
theorem theta_bracket {p : Module.End R L × Module.End R L} (hp : IsLBider br p) (a : L) :
    bracket (theta br a) p = -theta br (p.1 a) := by
  obtain ⟨hd, -, -⟩ := hp
  simp only [bracket, theta, Prod.neg_mk, Prod.mk.injEq]
  constructor
  · ext x
    simp only [LinearMap.sub_apply, Module.End.mul_apply, LinearMap.neg_apply,
      LinearMap.flip_apply, map_neg, neg_neg]
    rw [hd]; abel
  · ext x
    simp only [LinearMap.sub_apply, Module.End.mul_apply, LinearMap.neg_apply]
    rw [hd]; abel

/-- The compatibility condition is equivalent to `(d - D)(L) ⊆ Ann_r(L)`. -/
theorem compat_iff (d D : Module.End R L) :
    (∀ x y, br x (d y) = br x (D y)) ↔ ∀ y, d y - D y ∈ annR br := by
  constructor
  · intro h y x; rw [map_sub, h x y, sub_self]
  · intro h x y; have := h y x; rwa [map_sub, sub_eq_zero] at this

/-- `ker ι_L = Ann(L)`. -/
theorem theta_eq_zero_iff (a : L) : theta br a = 0 ↔ a ∈ ann br := by
  constructor
  · intro h
    have h1 := congrArg Prod.fst h
    have h2 := congrArg Prod.snd h
    refine ⟨fun x => ?_, fun x => ?_⟩
    · have := LinearMap.congr_fun h2 x; simpa [theta] using this
    · have := LinearMap.congr_fun h1 x; simpa [theta] using this
  · rintro ⟨h1, h2⟩
    simp only [theta]
    ext x
    · simp [h2 x]
    · simp [h1 x]

/-- `(0, D)` is a Loday-biderivation iff `D` is a Loday-antiderivation with values in
`Ann_r(L)`. -/
theorem isLBider_zero_iff (D : Module.End R L) :
    IsLBider br (0, D) ↔ IsADer br D ∧ ∀ y, D y ∈ annR br := by
  constructor
  · rintro ⟨-, hD, hc⟩
    refine ⟨hD, fun y x => ?_⟩
    have := hc x y
    simpa using this.symm
  · rintro ⟨hD, hA⟩
    refine ⟨fun x y => by simp, hD, fun x y => ?_⟩
    simp [hA y x]

theorem IsLBider.sub {p q : Module.End R L × Module.End R L}
    (hp : IsLBider br p) (hq : IsLBider br q) : IsLBider br (p - q) := by
  obtain ⟨hd, hD, hc⟩ := hp
  obtain ⟨hd', hD', hc'⟩ := hq
  unfold IsDer at hd hd'
  unfold IsADer at hD hD'
  refine ⟨fun x y => ?_, fun x y => ?_, fun x y => ?_⟩
  · simp only [Prod.fst_sub, LinearMap.sub_apply, map_sub, hd, hd', LinearMap.sub_apply]
    abel
  · simp only [Prod.snd_sub, LinearMap.sub_apply, map_sub, hD, hD', LinearMap.sub_apply]
    abel
  · simp only [Prod.fst_sub, Prod.snd_sub, LinearMap.sub_apply, map_sub, hc, hc']

/-- **Criterion for innerness.**  Every Loday-biderivation of `L` is inner if and only if
(i) the derivation component of every Loday-biderivation is an inner derivation `-R_a`, and
(ii) every Loday-antiderivation with values in `Ann_r(L)` is of the form `L_b` with
`b ∈ Ann_r(L)`. -/
theorem allInner_iff (hL : IsRightLeibniz br) :
    (∀ p, IsLBider br p → ∃ a, p = theta br a) ↔
      ((∀ p, IsLBider br p → ∃ a, p.1 = -(br.flip a)) ∧
        (∀ D, IsADer br D → (∀ y, D y ∈ annR br) → ∃ b ∈ annR br, D = br b)) := by
  constructor
  · intro h
    refine ⟨fun p hp => ?_, fun D hD hA => ?_⟩
    · obtain ⟨a, rfl⟩ := h p hp
      exact ⟨a, rfl⟩
    · obtain ⟨b, hb⟩ := h (0, D) ((isLBider_zero_iff D).2 ⟨hD, hA⟩)
      have h1 := congrArg Prod.fst hb
      have h2 := congrArg Prod.snd hb
      refine ⟨b, fun x => ?_, h2⟩
      have := LinearMap.congr_fun h1 x
      simpa [theta] using this.symm
  · rintro ⟨h1, h2⟩ p hp
    obtain ⟨a, ha⟩ := h1 p hp
    have hq : IsLBider br (p - theta br a) := hp.sub (theta_isLBider hL a)
    have hfst : (p - theta br a).1 = 0 := by simp [theta, ha]
    have hq' : IsLBider br (0, (p - theta br a).2) := by
      rw [← hfst]; exact hq
    obtain ⟨hD, hA⟩ := (isLBider_zero_iff _).1 hq'
    obtain ⟨b, hb, hbD⟩ := h2 _ hD hA
    refine ⟨a + b, ?_⟩
    have hRb : br.flip b = 0 := by
      ext x; simpa using hb x
    ext x
    · simp [theta, ha, hRb]
    · have := LinearMap.congr_fun hbD x
      simp only [Prod.snd_sub, LinearMap.sub_apply, theta] at this
      simp only [theta, map_add, LinearMap.add_apply]
      rw [← this]; abel

end LodayBider
