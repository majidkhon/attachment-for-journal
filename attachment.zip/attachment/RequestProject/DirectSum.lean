module

public import RequestProject.LodayBiderivation

/-!
# Loday-biderivations of a direct sum of two ideals (Proposition 2.11)

For right Leibniz algebras `A`, `B` we equip `A × B` with the componentwise product,
so that `A` and `B` are ideals with `[A, B] = [B, A] = 0`.  A linear map `d` of `A × B`
is written as a block matrix
`d = (d_A ψ; φ d_B)` with `d_A : A → A`, `ψ : B → A`, `φ : A → B`, `d_B : B → B`.

* `LodayBider.isLBider_prod_iff` : `(d, D)` is a Loday-biderivation of `A × B` iff
  the diagonal blocks are Loday-biderivations of `A` and `B`, the off-diagonal blocks
  of `d` and `D` take values in the annihilators, and they vanish on `A²`, resp. `B²`.
* `LodayBider.theta_prod` : inner Loday-biderivations are block-diagonal.
-/

@[expose] public section

namespace LodayBider

variable {R A B : Type*} [CommRing R] [AddCommGroup A] [Module R A]
  [AddCommGroup B] [Module R B]

/-- The componentwise product on `A × B`. -/
def prodBr (brA : A →ₗ[R] A →ₗ[R] A) (brB : B →ₗ[R] B →ₗ[R] B) :
    (A × B) →ₗ[R] (A × B) →ₗ[R] (A × B) :=
  LinearMap.mk₂ R (fun x y => (brA x.1 y.1, brB x.2 y.2))
    (by intros; simp) (by intros; simp) (by intros; simp) (by intros; simp)

@[simp] theorem prodBr_apply (brA : A →ₗ[R] A →ₗ[R] A) (brB : B →ₗ[R] B →ₗ[R] B)
    (x y : A × B) : prodBr brA brB x y = (brA x.1 y.1, brB x.2 y.2) := rfl

/-- Block `A → A` of an endomorphism of `A × B`. -/
def blkAA (d : Module.End R (A × B)) : Module.End R A :=
  LinearMap.fst R A B ∘ₗ d ∘ₗ LinearMap.inl R A B
/-- Block `B → A` of an endomorphism of `A × B`. -/
def blkAB (d : Module.End R (A × B)) : B →ₗ[R] A :=
  LinearMap.fst R A B ∘ₗ d ∘ₗ LinearMap.inr R A B
/-- Block `A → B` of an endomorphism of `A × B`. -/
def blkBA (d : Module.End R (A × B)) : A →ₗ[R] B :=
  LinearMap.snd R A B ∘ₗ d ∘ₗ LinearMap.inl R A B
/-- Block `B → B` of an endomorphism of `A × B`. -/
def blkBB (d : Module.End R (A × B)) : Module.End R B :=
  LinearMap.snd R A B ∘ₗ d ∘ₗ LinearMap.inr R A B

theorem apply_fst (d : Module.End R (A × B)) (x : A × B) :
    (d x).1 = blkAA d x.1 + blkAB d x.2 := by
  simp only [blkAA, blkAB, LinearMap.coe_comp, Function.comp_apply, LinearMap.fst_apply,
    LinearMap.inl_apply, LinearMap.inr_apply, ← Prod.fst_add, ← map_add, Prod.mk_add_mk,
    add_zero, zero_add]

theorem apply_snd (d : Module.End R (A × B)) (x : A × B) :
    (d x).2 = blkBA d x.1 + blkBB d x.2 := by
  simp only [blkBA, blkBB, LinearMap.coe_comp, Function.comp_apply, LinearMap.snd_apply,
    LinearMap.inl_apply, LinearMap.inr_apply, ← Prod.snd_add, ← map_add, Prod.mk_add_mk,
    add_zero, zero_add]

variable {brA : A →ₗ[R] A →ₗ[R] A} {brB : B →ₗ[R] B →ₗ[R] B}

/-- **Proposition 2.11.**  A pair `(d, D)` of linear maps of `A ⊕ B` is a
Loday-biderivation if and only if
* `(d_A, D_A)` is a Loday-biderivation of `A` and `(d_B, D_B)` one of `B`;
* the off-diagonal blocks `φ, φ' : A → B` of `d, D` take values in `Ann(B)` and vanish on
  `A² = [A, A]`;
* the off-diagonal blocks `ψ, ψ' : B → A` of `d, D` take values in `Ann(A)` and vanish on
  `B² = [B, B]`. -/
theorem isLBider_prod_iff (d D : Module.End R (A × B)) :
    IsLBider (prodBr brA brB) (d, D) ↔
      IsLBider brA (blkAA d, blkAA D) ∧ IsLBider brB (blkBB d, blkBB D) ∧
      (∀ a, blkBA d a ∈ ann brB ∧ blkBA D a ∈ ann brB) ∧
      (∀ a a', blkBA d (brA a a') = 0 ∧ blkBA D (brA a a') = 0) ∧
      (∀ b, blkAB d b ∈ ann brA ∧ blkAB D b ∈ ann brA) ∧
      (∀ b b', blkAB d (brB b b') = 0 ∧ blkAB D (brB b b') = 0) := by
  constructor
  · rintro ⟨hd, hD, hc⟩
    have hdf := fun x y => congrArg Prod.fst (hd x y)
    have hds := fun x y => congrArg Prod.snd (hd x y)
    have hDf := fun x y => congrArg Prod.fst (hD x y)
    have hDs := fun x y => congrArg Prod.snd (hD x y)
    have hcf := fun x y => congrArg Prod.fst (hc x y)
    have hcs := fun x y => congrArg Prod.snd (hc x y)
    simp only [prodBr_apply, apply_fst, apply_snd, Prod.fst_add, Prod.snd_add,
      Prod.fst_sub, Prod.snd_sub, map_add, LinearMap.add_apply] at hdf hds hDf hDs hcf hcs
    refine ⟨⟨fun a a' => ?_, fun a a' => ?_, fun a a' => ?_⟩,
      ⟨fun b b' => ?_, fun b b' => ?_, fun b b' => ?_⟩,
      fun a => ⟨⟨fun b => ?_, fun b => ?_⟩, ⟨fun b => ?_, fun b => ?_⟩⟩,
      fun a a' => ⟨?_, ?_⟩,
      fun b => ⟨⟨fun a => ?_, fun a => ?_⟩, ⟨fun a => ?_, fun a => ?_⟩⟩,
      fun b b' => ⟨?_, ?_⟩⟩
    · simpa using hdf (a, 0) (a', 0)
    · simpa using hDf (a, 0) (a', 0)
    · simpa using hcf (a, 0) (a', 0)
    · simpa using hds (0, b) (0, b')
    · simpa using hDs (0, b) (0, b')
    · simpa using hcs (0, b) (0, b')
    · simpa using (hds (a, 0) (0, b)).symm
    · simpa using (hds (0, b) (a, 0)).symm
    · simpa using (hDs (a, 0) (0, b)).symm
    · have h1 := hcs (0, b) (a, 0)
      have h2 := hds (0, b) (a, 0)
      simp at h1 h2
      rw [← h1]; simpa using h2.symm
    · simpa using hds (a, 0) (a', 0)
    · simpa using hDs (a, 0) (a', 0)
    · simpa using (hdf (0, b) (a, 0)).symm
    · simpa using (hdf (a, 0) (0, b)).symm
    · simpa using (hDf (0, b) (a, 0)).symm
    · have h1 := hcf (a, 0) (0, b)
      have h2 := hdf (a, 0) (0, b)
      simp at h1 h2
      rw [← h1]; simpa using h2.symm
    · simpa using hdf (0, b) (0, b')
    · simpa using hDf (0, b) (0, b')
  · rintro ⟨⟨hdA, hDA, hcA⟩, ⟨hdB, hDB, hcB⟩, hBA, hBA2, hAB, hAB2⟩
    unfold IsDer at hdA hdB
    unfold IsADer at hDA hDB
    dsimp only at hdA hdB hDA hDB hcA hcB
    refine ⟨fun x y => ?_, fun x y => ?_, fun x y => ?_⟩
    · ext
      · simp only [prodBr_apply, apply_fst, Prod.fst_add, map_add, LinearMap.add_apply,
          hdA, (hAB2 _ _).1, (hAB _).1.1, (hAB _).1.2]
        abel
      · simp only [prodBr_apply, apply_snd, Prod.snd_add, map_add, LinearMap.add_apply,
          hdB, (hBA2 _ _).1, (hBA _).1.1, (hBA _).1.2]
        abel
    · ext
      · simp only [prodBr_apply, apply_fst, Prod.fst_sub, map_add, LinearMap.add_apply,
          hDA, (hAB2 _ _).2, (hAB _).2.1]
        abel
      · simp only [prodBr_apply, apply_snd, Prod.snd_sub, map_add, LinearMap.add_apply,
          hDB, (hBA2 _ _).2, (hBA _).2.1]
        abel
    · ext
      · simp only [prodBr_apply, apply_fst, map_add, hcA, (hAB _).1.2, (hAB _).2.2]
      · simp only [prodBr_apply, apply_snd, map_add, hcB, (hBA _).1.2, (hBA _).2.2]

/-- Inner Loday-biderivations of `A ⊕ B` are block-diagonal, with blocks `Θ_a` and `Θ_b`;
hence `ILBider(A ⊕ B) = ILBider(A) ⊕ ILBider(B)`. -/
theorem theta_prod (a : A) (b : B) :
    blkAA (theta (prodBr brA brB) (a, b)).1 = (theta brA a).1 ∧
    blkAA (theta (prodBr brA brB) (a, b)).2 = (theta brA a).2 ∧
    blkBB (theta (prodBr brA brB) (a, b)).1 = (theta brB b).1 ∧
    blkBB (theta (prodBr brA brB) (a, b)).2 = (theta brB b).2 ∧
    blkAB (theta (prodBr brA brB) (a, b)).1 = 0 ∧ blkAB (theta (prodBr brA brB) (a, b)).2 = 0 ∧
    blkBA (theta (prodBr brA brB) (a, b)).1 = 0 ∧ blkBA (theta (prodBr brA brB) (a, b)).2 = 0 := by
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩ <;> ext <;> simp [theta, blkAA, blkAB, blkBA, blkBB]

end LodayBider
