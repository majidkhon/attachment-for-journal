module

public import RequestProject.InnernessCriterion

/-!
# The solvable extension `R` of the null-filiform algebra `NF_n` (Section 4)

`R` has basis `h, e_1, …, e_n` and nonzero brackets
`[e_i, e_1] = e_{i+1}` (`1 ≤ i < n`), `[h, e_1] = -e_1`, `[e_i, h] = i e_i` (`1 ≤ i ≤ n`).
We model `R` as `Fin (n+1) → K`, coordinate `0` being `h` and coordinate `i ≥ 1` being `e_i`.

We check both hypotheses of the innerness criterion (Corollary `cor:criterion`) for `R`:

* `SolvableNF.der_inner` : every derivation of `R` is inner, so in particular
  `pr₁(LBider(R)) ⊆ Inn(R)`;
* `SolvableNF.H1_vanish` : every `Ann_r(R)`-valued Loday-antiderivation is `L_b` with
  `b ∈ Ann_r(R)`, i.e. `H¹(𝔤_R, Ann_r(R)) = 0`;

and deduce (`SolvableNF.all_inner`) that every Loday-biderivation of `R` is inner, and that
`ι_R` is injective (`Ann(R) = 0`).
-/

@[expose] public section

namespace LodayBider.SolvableNF

variable {K : Type*} [Field K]

/-- Structure constants of `R`, written on `ℕ`-indexed coordinate vectors
(index `0` is `h`, index `i ≥ 1` is `e_i`). -/
def brN (X Y : ℕ → K) (k : ℕ) : K :=
  if k = 0 then 0 else if k = 1 then X 1 * Y 0 - X 0 * Y 1
  else X (k-1) * Y 1 + (k:K) * X k * Y 0

theorem brN_leib (X Y Z : ℕ → K) (k : ℕ) :
    brN (brN X Y) Z k = brN (brN X Z) Y k + brN X (brN Y Z) k := by
  rcases k with _ | _ | _ | k
  · simp [brN]
  · simp [brN]; ring
  · simp [brN]; ring
  · simp [brN]; ring

/-- Extension of a coordinate vector by zero. -/
def toN {n : ℕ} (x : Fin (n+1) → K) (k : ℕ) : K := if h : k < n+1 then x ⟨k, h⟩ else 0

theorem toN_add {n : ℕ} (x y : Fin (n+1) → K) : toN (x + y) = toN x + toN y := by
  funext k; simp only [toN, Pi.add_apply]; split_ifs <;> simp

theorem toN_smul {n : ℕ} (c : K) (x : Fin (n+1) → K) : toN (c • x) = c • toN x := by
  funext k; simp only [toN, Pi.smul_apply]; split_ifs <;> simp

/-- The bracket of `R`. -/
def brR (n : ℕ) : (Fin (n+1) → K) →ₗ[K] (Fin (n+1) → K) →ₗ[K] (Fin (n+1) → K) :=
  LinearMap.mk₂ K (fun x y k => brN (toN x) (toN y) k)
    (by intro x x' y; funext k; simp only [toN_add, brN, Pi.add_apply]; split_ifs <;> ring)
    (by intro c x y; funext k; simp only [toN_smul, brN, Pi.smul_apply, smul_eq_mul];
        split_ifs <;> ring)
    (by intro x y y'; funext k; simp only [toN_add, brN, Pi.add_apply]; split_ifs <;> ring)
    (by intro c x y; funext k; simp only [toN_smul, brN, Pi.smul_apply, smul_eq_mul];
        split_ifs <;> ring)

theorem brR_apply {n : ℕ} (x y : Fin (n+1) → K) (k : Fin (n+1)) :
    brR n x y k = brN (toN x) (toN y) k := rfl

theorem toN_brR {n : ℕ} (x y : Fin (n+1) → K) (k : ℕ) (hk : k < n + 1) :
    toN (brR n x y) k = brN (toN x) (toN y) k := by
  simp [toN, hk, brR_apply]

/-- `brN X Y k` only depends on `X` at indices `≤ k` and on `Y` at indices `0, 1`. -/
theorem brN_congr_left {X X' Y : ℕ → K} {k : ℕ} (h : ∀ j ≤ k, X j = X' j) :
    brN X Y k = brN X' Y k := by
  unfold brN
  split_ifs with h0 h1
  · rfl
  · rw [h 1 (by omega), h 0 (by omega)]
  · rw [h (k-1) (by omega), h k le_rfl]

theorem brN_congr_right {X Y Y' : ℕ → K} {k : ℕ} (h0 : Y 0 = Y' 0) (h1 : Y 1 = Y' 1) :
    brN X Y k = brN X Y' k := by
  unfold brN; rw [h0, h1]

theorem brR_leibniz (n : ℕ) : IsRightLeibniz (brR (K := K) n) := by
  intro x y z
  funext k
  simp only [Pi.add_apply, brR_apply]
  by_cases hk0 : (k : ℕ) = 0
  · simp [brN, hk0]
  have hk := k.isLt
  have e1 : brN (toN (brR n x y)) (toN z) k = brN (brN (toN x) (toN y)) (toN z) k :=
    brN_congr_left fun j hj => toN_brR _ _ _ (by omega)
  have e2 : brN (toN (brR n x z)) (toN y) k = brN (brN (toN x) (toN z)) (toN y) k :=
    brN_congr_left fun j hj => toN_brR _ _ _ (by omega)
  have e3 : brN (toN x) (toN (brR n y z)) k = brN (toN x) (brN (toN y) (toN z)) k :=
    brN_congr_right (toN_brR _ _ _ (by omega)) (toN_brR _ _ _ (by omega))
  rw [e1, e2, e3]
  exact brN_leib _ _ _ _


/-! ### Basis vectors -/

/-- The basis vector with index `k` (`bv n 0 = h`, `bv n k = e_k`). -/
def bv (n k : ℕ) : Fin (n+1) → K := fun j => if (j : ℕ) = k then 1 else 0

theorem toN_bv {n k : ℕ} (hk : k ≤ n) (j : ℕ) :
    toN (bv (K := K) n k) j = if j = k then 1 else 0 := by
  unfold toN bv
  split_ifs <;> simp_all

theorem eq_of_toN {n : ℕ} {u u' : Fin (n+1) → K} (h : ∀ j < n + 1, toN u j = toN u' j) :
    u = u' := by
  funext j
  have := h j j.isLt
  simp only [toN, dif_pos j.isLt] at this
  exact this

theorem linearMap_ext_bv {n : ℕ} {M : Type*} [AddCommGroup M] [Module K M]
    {f g : (Fin (n+1) → K) →ₗ[K] M} (h : ∀ k ≤ n, f (bv n k) = g (bv n k)) : f = g := by
  apply LinearMap.pi_ext
  intro i c
  have hs : (Pi.single i c : Fin (n+1) → K) = c • bv n i := by
    funext j
    by_cases hj : j = i
    · subst hj; simp [bv]
    · simp [bv, hj, Fin.val_ne_of_ne hj]
  rw [hs, map_smul, map_smul, h i (by omega)]

/-- `[e_k, e_1] = e_{k+1}` for `1 ≤ k < n`. -/
theorem br_bv_succ {n k : ℕ} (hk1 : 1 ≤ k) (hkn : k < n) :
    brR (K := K) n (bv n k) (bv n 1) = bv n (k+1) := by
  apply eq_of_toN
  intro j hj
  rw [toN_brR _ _ _ hj, toN_bv (by omega) j]
  simp only [brN, toN_bv (show k ≤ n by omega), toN_bv (show 1 ≤ n by omega)]
  rcases j with _ | _ | j <;> simp
  split_ifs <;> first | omega | simp

theorem toN_zero {n : ℕ} : toN (0 : Fin (n+1) → K) = 0 := by
  funext k; simp [toN]

theorem toN_neg {n : ℕ} (x : Fin (n+1) → K) : toN (-x) = -toN x := by
  funext k; simp only [toN, Pi.neg_apply]; split_ifs <;> simp

theorem toN_sub {n : ℕ} (x y : Fin (n+1) → K) : toN (x - y) = toN x - toN y := by
  funext k; simp only [toN, Pi.sub_apply]; split_ifs <;> simp

theorem toN_out {n : ℕ} (x : Fin (n+1) → K) {k : ℕ} (hk : n < k) : toN x k = 0 := by
  simp [toN]; omega

/-- `[e_k, h] = k e_k`. -/
theorem br_bv_zero {n k : ℕ} (hk : k ≤ n) :
    brR (K := K) n (bv n k) (bv n 0) = (k : K) • bv n k := by
  apply eq_of_toN
  intro j hj
  rw [toN_brR _ _ _ hj, toN_smul]
  simp only [brN, toN_bv hk, toN_bv (Nat.zero_le n), Pi.smul_apply, smul_eq_mul]
  by_cases hjk : j = k
  · subst hjk; rcases j with _ | _ | j <;> simp
  · rcases j with _ | _ | j <;> simp [hjk]

/-- Two derivations of `R` agreeing on the generators `h, e_1` coincide. -/
theorem der_ext {n : ℕ} {d d' : Module.End K (Fin (n+1) → K)}
    (hd : IsDer (brR n) d) (hd' : IsDer (brR n) d')
    (h0 : d (bv n 0) = d' (bv n 0)) (h1 : d (bv n 1) = d' (bv n 1)) : d = d' := by
  apply linearMap_ext_bv
  intro k hk
  induction k with
  | zero => exact h0
  | succ k ih =>
    rcases Nat.eq_zero_or_pos k with rfl | hk1
    · exact h1
    · rw [← br_bv_succ hk1 (by omega), hd, hd', ih (by omega), h1]

/-- `Ann_r(R) = span{e_2, …, e_n}`. -/
theorem mem_annR_iff {n : ℕ} (hn : 1 ≤ n) (y : Fin (n+1) → K) :
    y ∈ annR (brR n) ↔ toN y 0 = 0 ∧ toN y 1 = 0 := by
  constructor
  · intro hy
    have h1 := congrArg (fun u => toN u 1) (hy (bv n 0))
    have h2 := congrArg (fun u => toN u 1) (hy (bv n 1))
    simp [toN_brR _ _ _ (show 1 < n + 1 by omega), brN, toN_bv hn, toN_bv (Nat.zero_le n),
      toN_zero] at h1 h2
    exact ⟨h2, h1⟩
  · rintro ⟨h0, h1⟩ x
    apply eq_of_toN
    intro j hj
    rw [toN_brR _ _ _ hj, toN_zero]
    simp [brN, h0, h1]

variable [CharZero K]

/-- `Ann(R) = 0`. -/
theorem ann_trivial {n : ℕ} (hn : 1 ≤ n) (a : Fin (n+1) → K) (ha : a ∈ ann (brR n)) : a = 0 := by
  obtain ⟨hl, hr⟩ := ha
  obtain ⟨h0, h1⟩ := (mem_annR_iff hn a).1 hr
  apply eq_of_toN
  intro j hj
  rw [toN_zero]
  rcases j with _ | _ | j
  · simpa using h0
  · simpa using h1
  · have := congrArg (fun u => toN u (j+2)) (hl (bv n 0))
    simp [toN_brR _ _ _ hj, brN, toN_bv (Nat.zero_le n), toN_zero] at this
    exact this.resolve_left (by norm_cast)

/-- **Condition (i) for `R`.** Every derivation of `R` is inner: `d = -R_a`.
In particular `pr₁(LBider(R)) ⊆ Inn(R)`. -/
theorem der_inner {n : ℕ} (hn : 1 ≤ n) (d : Module.End K (Fin (n+1) → K))
    (hd : IsDer (brR n) d) : ∃ a, d = -((brR n).flip a) := by
  set v := d (bv n 0) with hv
  set w := d (bv n 1) with hw
  refine ⟨(-(toN w 1)) • bv n 0 + (toN v 1) • bv n 1,
    der_ext hd (theta_isLBider (brR_leibniz n) _).1 ?_ ?_⟩
  · have E1 := hd (bv n 0) (bv n 0)
    have E2 := hd (bv n 1) (bv n 0)
    rw [br_bv_zero (Nat.zero_le n)] at E1
    rw [br_bv_zero hn] at E2
    have F1 := fun j => congrArg (fun u => toN u j) E1
    have F2 := fun j => congrArg (fun u => toN u j) E2
    simp only [LinearMap.neg_apply, LinearMap.flip_apply]
    apply eq_of_toN
    intro j hj
    have G1 := F1 j
    have G2 := F2 1
    simp [toN_brR _ _ _ hj, toN_brR _ _ _ (show 1 < n + 1 by omega), toN_neg, toN_add,
      toN_smul, brN, toN_bv hn, toN_bv (Nat.zero_le n), ← hv, ← hw, toN_zero] at G1 G2 ⊢
    rcases j with _ | _ | j
    · simpa using G2
    · simp
    · simp at G1 ⊢
      exact G1.resolve_left (by norm_cast)
  · have E2 := hd (bv n 1) (bv n 0)
    rw [br_bv_zero hn] at E2
    have F2 := fun j => congrArg (fun u => toN u j) E2
    simp only [LinearMap.neg_apply, LinearMap.flip_apply]
    apply eq_of_toN
    intro j hj
    have G2 := F2 j
    simp [toN_brR _ _ _ hj, toN_neg, toN_add,
      toN_smul, brN, toN_bv hn, toN_bv (Nat.zero_le n), ← hv, ← hw] at G2 ⊢
    rcases j with _ | _ | _ | j
    · simpa using G2
    · simp
    · simp at G2 ⊢
      linear_combination -G2
    · simp at G2 ⊢
      have h2 : ((j : K) + 3) - 1 ≠ 0 := by
        have : ((j : K) + 3) - 1 = ((j + 2 : ℕ) : K) := by push_cast; ring
        rw [this]; norm_cast
      have : (((j : K) + 3) - 1) * toN w (j + 1 + 1 + 1) = 0 := by
        linear_combination -G2
      exact (mul_eq_zero.1 this).resolve_left h2

omit [CharZero K] in
theorem bv_mem_annR {n k : ℕ} (hn : 1 ≤ n) (hk2 : 2 ≤ k) (hkn : k ≤ n) :
    bv (K := K) n k ∈ annR (brR n) := by
  rw [mem_annR_iff hn, toN_bv hkn, toN_bv hkn]
  constructor <;> (rw [if_neg (by omega)])

/-- A Loday-antiderivation of `R` vanishes on `e_k`, `k ≥ 2` (these span `Leib(R)`). -/
theorem ader_bv {n k : ℕ} (hn : 1 ≤ n) (hk2 : 2 ≤ k) (hkn : k ≤ n)
    (D : Module.End K (Fin (n+1) → K)) (hD : IsADer (brR n) D) : D (bv n k) = 0 := by
  have e := hD (bv n k) (bv n 0)
  have e' := hD (bv n 0) (bv n k)
  rw [br_bv_zero hkn] at e
  rw [bv_mem_annR hn hk2 hkn (bv n 0), map_zero] at e'
  have hsum : (k : K) • D (bv n k) = 0 := by
    rw [← map_smul, e]
    rw [← sub_eq_zero] at e'
    linear_combination (norm := module) e'
  rcases smul_eq_zero.1 hsum with h | h
  · exfalso; norm_cast at h; omega
  · exact h

/-- **Condition (ii) for `R`.** Every Loday-antiderivation of `R` with values in `Ann_r(R)`
is a left multiplication `L_b` by some `b ∈ Ann_r(R)`; equivalently (Proposition `prop:cohom`)
`H¹(𝔤_R, Ann_r(R)) = 0`. -/
theorem H1_vanish {n : ℕ} (hn : 1 ≤ n) (D : Module.End K (Fin (n+1) → K))
    (hD : IsADer (brR n) D) (hA : ∀ y, D y ∈ annR (brR n)) :
    ∃ b ∈ annR (brR n), D = brR n b := by
  set u := D (bv n 0) with hu
  set w := D (bv n 1) with hw
  obtain ⟨u0, u1⟩ := (mem_annR_iff hn u).1 (hA _)
  obtain ⟨w0, w1⟩ := (mem_annR_iff hn w).1 (hA _)
  set b : Fin (n+1) → K := fun j => u j / ((j : ℕ) : K) with hb
  have hbN : ∀ j, toN b j = toN u j / (j : K) := by
    intro j; simp only [toN, hb]; split_ifs <;> simp
  have hbA : b ∈ annR (brR n) := by
    rw [mem_annR_iff hn, hbN, hbN, u1]; simp
  refine ⟨b, hbA, ?_⟩
  apply linearMap_ext_bv
  intro k hk
  rcases k with _ | _ | k
  · apply eq_of_toN
    intro j hj
    rw [toN_brR _ _ _ hj]
    simp only [brN, toN_bv (Nat.zero_le n), hbN, ← hu]
    rcases j with _ | _ | j
    · simpa using u0
    · simp
    · have hj2 : (j : K) + 1 + 1 ≠ 0 := by norm_cast
      simp
      field_simp
  · have E := hD (bv n 1) (bv n 0)
    rw [br_bv_zero hn] at E
    apply eq_of_toN
    intro j hj
    have G := congrArg (fun x => toN x j) E
    simp [toN_brR _ _ _ hj, toN_sub, brN, toN_bv hn, toN_bv (Nat.zero_le n),
      ← hu, ← hw] at G
    rw [toN_brR _ _ _ hj]
    simp only [brN, toN_bv hn, hbN, ← hw]
    rcases j with _ | _ | j
    · simpa using w0
    · simpa using w1
    · simp at G ⊢
      have hj1 : (j : K) + 1 ≠ 0 := by norm_cast
      rw [eq_div_iff hj1]
      linear_combination -G
  · rw [ader_bv hn (by omega) hk D hD, bv_mem_annR hn (by omega) hk b]

/-- **Both hypotheses of Corollary `cor:criterion` hold for `R`:**
(i) `pr₁(LBider(R)) ⊆ Inn(R)`, and
(ii) `H¹(𝔤_R, Ann_r(R)) = 0`, i.e. every `Ann_r(R)`-valued Loday-antiderivation is `L_b`,
`b ∈ Ann_r(R)`. -/
theorem criterion_holds {n : ℕ} (hn : 1 ≤ n) :
    (∀ p, IsLBider (brR (K := K) n) p → ∃ a, p.1 = -((brR n).flip a)) ∧
      (∀ D, IsADer (brR (K := K) n) D → (∀ y, D y ∈ annR (brR n)) →
        ∃ b ∈ annR (brR n), D = brR n b) :=
  ⟨fun p hp => der_inner hn p.1 hp.1, H1_vanish hn⟩

/-- **Conclusion (Theorem `thm:R-inner`).** Every Loday-biderivation of `R` is inner, and
`a ↦ Θ_a` is injective; hence `LBider(R) = ILBider(R) ≅ R`. -/
theorem all_inner {n : ℕ} (hn : 1 ≤ n) :
    (∀ p, IsLBider (brR (K := K) n) p → ∃ a, p = theta (brR n) a) ∧
      Function.Injective (theta (brR (K := K) n)) := by
  refine ⟨(allInner_iff_H1 (brR_leibniz n)).2 (criterion_holds hn), fun a b hab => ?_⟩
  have h0 : theta (brR (K := K) n) (a - b) = 0 := by
    simp only [theta, map_sub] at hab ⊢
    rw [Prod.mk.injEq] at hab
    rw [Prod.mk_eq_zero, sub_eq_zero.2 (neg_inj.1 hab.1), sub_eq_zero.2 hab.2]
    simp
  exact sub_eq_zero.mp (ann_trivial hn _ ((theta_eq_zero_iff _).1 h0))

end LodayBider.SolvableNF
