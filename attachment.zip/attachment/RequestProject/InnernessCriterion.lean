module

public import RequestProject.GeneralizedBider

/-!
# A generalized innerness criterion (Remark 3(d))

* `LodayBider.isLBider_dphi_iff` : the description `LBider(L) ≅ {(d, φ)}` with
  `φ = d - D : L → Ann_r(L)` satisfying an explicit identity.
* `LodayBider.IsADer.map_leib`, `LodayBider.annR_br_mem`, … : an `Ann_r(L)`-valued
  Loday-antiderivation is a 1-cocycle of the Lie algebra `L / Leib(L)` with values in the
  module `Ann_r(L)`, and `L_b` (`b ∈ Ann_r(L)`) are exactly the coboundaries.
* `LodayBider.outer_exact_*` : the pieces of the exact sequence
  `0 → H¹(L/Leib L, Ann_r L) → LBider(L)/ILBider(L) → pr₁(LBider L)/Inn(L) → 0`.
* `LodayBider.allInner_iff_H1` : generalized criterion.
* `LodayBider.H1_vanish_of_weight` : a weight criterion for `H¹ = 0`.
* `LodayBider.iota_bijective_of_complete` : sufficient condition "in the spirit of complete
  Lie algebras" for `ι_L : L → LBider(L)` to be bijective.
-/

@[expose] public section

namespace LodayBider

variable {R L : Type*} [CommRing R] [AddCommGroup L] [Module R L]
variable {br : L →ₗ[R] L →ₗ[R] L}

/-! ### The `(d, φ)` description -/

/-- **`(d, φ)` description.** For linear maps `d, φ`, the pair `(d, d - φ)` is a
Loday-biderivation iff `d` is a derivation, `φ` takes values in `Ann_r(L)`, and
`φ[x,y] = [φ x, y] - [φ y, x] + [x, d y] + [d y, x]`. -/
theorem isLBider_dphi_iff (d φ : Module.End R L) :
    IsLBider br (d, d - φ) ↔
      IsDer br d ∧ (∀ y, φ y ∈ annR br) ∧
        ∀ x y, φ (br x y) = br (φ x) y - br (φ y) x + br x (d y) + br (d y) x := by
  constructor
  · rintro ⟨hd, hD, hc⟩
    have hphi : ∀ y, φ y ∈ annR br := by
      intro y x
      have := hc x y
      simp only [LinearMap.sub_apply, map_sub] at this
      linear_combination (norm := abel) this
    refine ⟨hd, hphi, fun x y => ?_⟩
    have h1 := hD x y
    have h2 := hd x y
    simp only [LinearMap.sub_apply, map_sub, LinearMap.sub_apply] at h1
    linear_combination (norm := abel) h2 - h1
  · rintro ⟨hd, hphi, heq⟩
    refine ⟨hd, fun x y => ?_, fun x y => ?_⟩
    · have h2 := hd x y
      have h3 := heq x y
      simp only [LinearMap.sub_apply, map_sub, LinearMap.sub_apply]
      linear_combination (norm := abel) h2 - h3
    · simp only [LinearMap.sub_apply, map_sub, hphi y x, sub_zero]

/-! ### Cohomological interpretation -/

/-- Every Loday-antiderivation kills `[x, x]`, hence the Leibniz kernel. -/
theorem IsADer.map_sq {D : Module.End R L} (hD : IsADer br D) (x : L) : D (br x x) = 0 := by
  have := hD x x
  rw [sub_self] at this
  exact this

theorem IsADer.map_leib {D : Module.End R L} (hD : IsADer br D) {u : L}
    (hu : u ∈ leibSub br) : D u = 0 := by
  induction hu using Submodule.span_induction with
  | mem u hu =>
    obtain ⟨x, y, rfl⟩ := hu
    have h1 := hD x y
    have h2 := hD y x
    rw [map_add, h1, h2]; abel
  | zero => simp
  | add u v _ _ hu hv => rw [map_add, hu, hv, add_zero]
  | smul c u _ hu => rw [map_smul, hu, smul_zero]

/-- `Ann_r(L)` is stable under right multiplication (so it is a right `L`-module). -/
theorem annR_br_mem (hL : IsRightLeibniz br) {m : L} (hm : m ∈ annR br) (x : L) :
    br m x ∈ annR br := by
  intro z
  have := hL z m x
  rw [hm z, map_zero, LinearMap.zero_apply, (hm (br z x) : br (br z x) m = 0), zero_add] at this
  exact this.symm

/-- `Leib(L)` acts trivially on `Ann_r(L)`, so `Ann_r(L)` is a module over the Lie algebra
`L / Leib(L)`. -/
theorem leib_acts_trivially (hL : IsRightLeibniz br) (m : L) {u : L} (hu : u ∈ leibSub br) :
    br m u = 0 := by
  exact (leibSub_le_annR hL hu : u ∈ annR br) m

/-- Coboundaries: `L_b` with `b ∈ Ann_r(L)` is an `Ann_r(L)`-valued Loday-antiderivation. -/
theorem coboundary_mem (hL : IsRightLeibniz br) {b : L} (hb : b ∈ annR br) :
    IsADer br (br b) ∧ ∀ y, br b y ∈ annR br := by
  exact ⟨(theta_isLBider hL b).2.1, fun y => annR_br_mem hL hb y⟩

/-! ### The exact sequence -/

/-- Exactness at `H¹`: `(0, D)` is inner iff `D = L_b` with `b ∈ Ann_r(L)`. -/
theorem outer_exact_left (D : Module.End R L) :
    (∃ a, ((0 : Module.End R L), D) = theta br a) ↔ ∃ b ∈ annR br, D = br b := by
  constructor
  · rintro ⟨a, ha⟩
    have h1 := congrArg Prod.fst ha
    have h2 := congrArg Prod.snd ha
    refine ⟨a, fun x => ?_, h2⟩
    have := LinearMap.congr_fun h1 x
    simpa [theta] using this.symm
  · rintro ⟨b, hb, rfl⟩
    refine ⟨b, ?_⟩
    simp only [theta, Prod.mk.injEq, and_true]
    ext x
    simp [hb x]

/-- Exactness in the middle: a Loday-biderivation with inner derivation part `-R_a`
differs from `Θ_a` by `(0, D')` with `D'` an `Ann_r(L)`-valued Loday-antiderivation. -/
theorem outer_exact_middle (hL : IsRightLeibniz br) {p : Module.End R L × Module.End R L}
    (hp : IsLBider br p) {a : L} (ha : p.1 = -(br.flip a)) :
    p = theta br a + (0, p.2 - br a) ∧ IsADer br (p.2 - br a) ∧
      ∀ y, (p.2 - br a) y ∈ annR br := by
  have hq : IsLBider br (p - theta br a) := hp.sub (theta_isLBider hL a)
  have hfst : (p - theta br a).1 = 0 := by simp [theta, ha]
  have hq' : IsLBider br (0, (p - theta br a).2) := by
    rw [← hfst]; exact hq
  obtain ⟨hD, hA⟩ := (isLBider_zero_iff _).1 hq'
  refine ⟨?_, hD, hA⟩
  ext x
  · simp [theta, ha]
  · simp [theta]

/-- **Generalized criterion.** All Loday-biderivations are inner iff (i) every derivation
part is inner and (ii) `H¹(L/Leib(L), Ann_r(L)) = 0`, i.e. every `Ann_r(L)`-valued
Loday-antiderivation (= 1-cocycle) is a coboundary `L_b`, `b ∈ Ann_r(L)`. -/
theorem allInner_iff_H1 (hL : IsRightLeibniz br) :
    (∀ p, IsLBider br p → ∃ a, p = theta br a) ↔
      ((∀ p, IsLBider br p → ∃ a, p.1 = -(br.flip a)) ∧
        (∀ D, IsADer br D → (∀ y, D y ∈ annR br) → ∃ b ∈ annR br, D = br b)) :=
  allInner_iff hL

/-! ### A weight criterion for `H¹ = 0` -/

omit [AddCommGroup L] [Module R L] in
theorem commute_aeval_of_commute {M : Type*} [AddCommGroup M] [Module R M]
    {E f : Module.End R M} (hc : Commute E f) (P : Polynomial R) :
    Commute E (Polynomial.aeval f P) := by
  induction P using Polynomial.induction_on' with
  | add p q hp hq => rw [map_add]; exact hp.add_right hq
  | monomial n a =>
    rw [Polynomial.aeval_monomial]
    exact (show Commute E (algebraMap R _ a) from (Algebra.commutes a E).symm).mul_right
      (hc.pow_right n)

/-- **Weight criterion.** Let `h ∈ L` and a polynomial `P` be such that
(a) `P(R_h)` maps `L` into `Leib(L)`, (b) `P(R_h)` is injective on `Ann_r(L)`, and
(c) `R_h` maps `Ann_r(L)` onto itself.  Then every `Ann_r(L)`-valued Loday-antiderivation
is `L_b` for some `b ∈ Ann_r(L)`. -/
theorem H1_vanish_of_weight (hL : IsRightLeibniz br) (h : L) (P : Polynomial R)
    (hP : ∀ x, Polynomial.aeval (br.flip h) P x ∈ leibSub br)
    (hinj : ∀ m ∈ annR br, Polynomial.aeval (br.flip h) P m = 0 → m = 0)
    (hsurj : ∀ m ∈ annR br, ∃ b ∈ annR br, br b h = m) :
    ∀ D, IsADer br D → (∀ y, D y ∈ annR br) → ∃ b ∈ annR br, D = br b := by
  intro D hD hDA
  obtain ⟨b, hb, hbh⟩ := hsurj (D h) (hDA h)
  have hLb := coboundary_mem hL hb
  set E : Module.End R L := D - br b with hEdef
  have hE : IsADer br E := by
    intro x y
    simp only [hEdef, LinearMap.sub_apply, map_sub, hD x y, hLb.1 x y]
    abel
  have hEA : ∀ y, E y ∈ annR br := fun y =>
    (annRSub br).sub_mem (hDA y) (hLb.2 y)
  have hcomm : Commute E (br.flip h) := by
    ext x
    simp only [Module.End.mul_apply, LinearMap.flip_apply, hEdef, LinearMap.sub_apply,
      map_sub, LinearMap.sub_apply]
    have h1 := hD x h
    have h2 := hL b x h
    rw [hbh] at h2
    rw [h1]
    linear_combination (norm := abel) h2
  have hcommP : Commute E (Polynomial.aeval (br.flip h) P) := commute_aeval_of_commute hcomm P
  have hE0 : ∀ x, E x = 0 := by
    intro x
    apply hinj _ (hEA x)
    have := LinearMap.congr_fun hcommP.eq x
    simp only [Module.End.mul_apply] at this
    rw [← this]
    exact hE.map_leib (hP x)
  refine ⟨b, hb, ?_⟩
  ext x
  have := hE0 x
  simp only [hEdef, LinearMap.sub_apply] at this
  exact sub_eq_zero.mp this

/-- **Sufficient condition (complete-type).** If every derivation is inner, the weight
hypotheses hold for some `h` and `P`, and `Ann(L) = 0`, then `ι_L : a ↦ Θ_a` is a bijection
from `L` onto `LBider(L)`. -/
theorem iota_bijective_of_complete (hL : IsRightLeibniz br)
    (hDer : ∀ d, IsDer br d → ∃ a, d = -(br.flip a))
    (h : L) (P : Polynomial R)
    (hP : ∀ x, Polynomial.aeval (br.flip h) P x ∈ leibSub br)
    (hinj : ∀ m ∈ annR br, Polynomial.aeval (br.flip h) P m = 0 → m = 0)
    (hsurj : ∀ m ∈ annR br, ∃ b ∈ annR br, br b h = m)
    (hAnn : ∀ a, a ∈ ann br → a = 0) :
    (∀ p, IsLBider br p → ∃ a, p = theta br a) ∧ Function.Injective (theta br) := by
  have hall : ∀ p, IsLBider br p → ∃ a, p = theta br a :=
    (allInner_iff hL).2 ⟨fun p hp => hDer p.1 hp.1, H1_vanish_of_weight hL h P hP hinj hsurj⟩
  refine ⟨hall, fun a b hab => ?_⟩
  have h0 : theta br (a - b) = 0 := by
    simp only [theta, map_sub] at hab ⊢
    have h1 := congrArg Prod.fst hab
    have h2 := congrArg Prod.snd hab
    ext x
    · have := LinearMap.congr_fun h1 x
      simp only [LinearMap.neg_apply, LinearMap.flip_apply, neg_inj] at this
      simp [this]
    · have := LinearMap.congr_fun h2 x
      simp [this]
  exact sub_eq_zero.mp (hAnn _ ((theta_eq_zero_iff _).1 h0))

/-! ### Dimension formula for the outer part -/

section Dimension

open Module

omit [CommRing R] [AddCommGroup L] [Module R L] in
theorem finrank_map_add_finrank_inf_ker {K V W : Type*} [Field K] [AddCommGroup V]
    [Module K V] [AddCommGroup W] [Module K W] [FiniteDimensional K V]
    (f : V →ₗ[K] W) (p : Submodule K V) :
    finrank K (p.map f) + finrank K ↥(p ⊓ LinearMap.ker f) = finrank K p := by
  have h := LinearMap.finrank_range_add_finrank_ker (f.domRestrict p)
  rw [LinearMap.range_domRestrict, LinearMap.ker_domRestrict] at h
  rw [← h]
  congr 1
  have e := Submodule.comapSubtypeEquivOfLe (q := p) (p := p ⊓ LinearMap.ker f) inf_le_left
  have hc : Submodule.comap p.subtype (p ⊓ LinearMap.ker f) =
      Submodule.comap p.subtype (LinearMap.ker f) := by
    ext x; simp
  rw [← e.finrank_eq, hc]

/-- `LBider(L)` as a submodule of `End(L) × End(L)`. -/
def lbiderSub (br : L →ₗ[R] L →ₗ[R] L) : Submodule R (Module.End R L × Module.End R L) where
  carrier := {p | IsLBider br p}
  add_mem' {p q} hp hq := by
    obtain ⟨hd, hD, hc⟩ := hp
    obtain ⟨hd', hD', hc'⟩ := hq
    refine ⟨fun x y => ?_, fun x y => ?_, fun x y => ?_⟩
    · simp only [Prod.fst_add, LinearMap.add_apply, map_add, hd x y, hd' x y]; abel
    · simp only [Prod.snd_add, LinearMap.add_apply, map_add, hD x y, hD' x y]; abel
    · simp only [Prod.fst_add, Prod.snd_add, LinearMap.add_apply, map_add, hc x y, hc' x y]
  zero_mem' := ⟨fun x y => by simp, fun x y => by simp, fun x y => by simp⟩
  smul_mem' c p hp := by
    obtain ⟨hd, hD, hc⟩ := hp
    refine ⟨fun x y => ?_, fun x y => ?_, fun x y => ?_⟩
    · simp only [Prod.smul_fst, LinearMap.smul_apply, map_smul, hd x y, smul_add,
        LinearMap.smul_apply]
    · simp only [Prod.smul_snd, LinearMap.smul_apply, map_smul, hD x y, smul_sub,
        LinearMap.smul_apply]
    · simp only [Prod.smul_fst, Prod.smul_snd, LinearMap.smul_apply, map_smul, hc x y]

/-- `ADer_0(L)`: Loday-antiderivations with values in `Ann_r(L)` (the 1-cocycles). -/
def ader0Sub (br : L →ₗ[R] L →ₗ[R] L) : Submodule R (Module.End R L) where
  carrier := {D | IsADer br D ∧ ∀ y, D y ∈ annR br}
  add_mem' {D E} hD hE := by
    refine ⟨fun x y => ?_, fun y => (annRSub br).add_mem (hD.2 y) (hE.2 y)⟩
    simp only [LinearMap.add_apply, map_add, hD.1 x y, hE.1 x y]; abel
  zero_mem' := ⟨fun x y => by simp, fun y => (annRSub br).zero_mem⟩
  smul_mem' c D hD := by
    refine ⟨fun x y => ?_, fun y => (annRSub br).smul_mem c (hD.2 y)⟩
    simp only [LinearMap.smul_apply, map_smul, hD.1 x y, smul_sub, LinearMap.smul_apply]

/-- The coboundaries `{L_b : b ∈ Ann_r(L)}`. -/
def cobSub (br : L →ₗ[R] L →ₗ[R] L) : Submodule R (Module.End R L) := (annRSub br).map br

/-- The inner derivations `Inn(L) = {R_a}`. -/
def innSub (br : L →ₗ[R] L →ₗ[R] L) : Submodule R (Module.End R L) := LinearMap.range br.flip

/-- `pr₁(LBider(L))`: derivation parts of Loday-biderivations. -/
def der1Sub (br : L →ₗ[R] L →ₗ[R] L) : Submodule R (Module.End R L) :=
  (lbiderSub br).map (LinearMap.fst R _ _)

/-- `ι_L` as a linear map. -/
def thetaLin (br : L →ₗ[R] L →ₗ[R] L) : L →ₗ[R] Module.End R L × Module.End R L :=
  LinearMap.prod (-br.flip) br

theorem thetaLin_apply (a : L) : thetaLin br a = theta br a := rfl

/-- `ILBider(L)` as a submodule. -/
def ilbiderSub (br : L →ₗ[R] L →ₗ[R] L) : Submodule R (Module.End R L × Module.End R L) :=
  LinearMap.range (thetaLin br)

theorem ilbiderSub_le (hL : IsRightLeibniz br) : ilbiderSub br ≤ lbiderSub br := by
  rintro _ ⟨a, rfl⟩; exact theta_isLBider hL a

theorem innSub_le (hL : IsRightLeibniz br) : innSub br ≤ der1Sub br := by
  rintro _ ⟨a, rfl⟩
  refine ⟨theta br (-a), theta_isLBider hL (-a), ?_⟩
  simp [theta]

theorem cobSub_le (hL : IsRightLeibniz br) : cobSub br ≤ ader0Sub br := by
  rintro _ ⟨b, hb, rfl⟩; exact coboundary_mem hL hb

theorem lbiderSub_inf_ker_fst :
    lbiderSub br ⊓ LinearMap.ker (LinearMap.fst R _ _) =
      (ader0Sub br).map (LinearMap.inr R (Module.End R L) (Module.End R L)) := by
  ext ⟨d, D⟩
  simp only [Submodule.mem_inf, LinearMap.mem_ker, LinearMap.fst_apply, Submodule.mem_map,
    LinearMap.inr_apply, Prod.mk.injEq]
  constructor
  · rintro ⟨hp, rfl⟩
    exact ⟨D, (isLBider_zero_iff D).1 hp, rfl, rfl⟩
  · rintro ⟨E, hE, rfl, rfl⟩
    exact ⟨(isLBider_zero_iff E).2 hE, rfl⟩

theorem ilbiderSub_inf_ker_fst :
    ilbiderSub br ⊓ LinearMap.ker (LinearMap.fst R _ _) =
      (cobSub br).map (LinearMap.inr R (Module.End R L) (Module.End R L)) := by
  ext ⟨d, D⟩
  simp only [Submodule.mem_inf, LinearMap.mem_ker, LinearMap.fst_apply, Submodule.mem_map,
    LinearMap.inr_apply, Prod.mk.injEq, ilbiderSub, LinearMap.mem_range, cobSub]
  constructor
  · rintro ⟨⟨a, ha⟩, rfl⟩
    have h1 := congrArg Prod.fst ha
    have h2 := congrArg Prod.snd ha
    simp only [thetaLin, LinearMap.prod_apply] at h1 h2
    refine ⟨D, ⟨a, fun x => ?_, h2⟩, rfl, rfl⟩
    have := LinearMap.congr_fun h1 x
    simpa using this
  · rintro ⟨E, ⟨b, hb, rfl⟩, rfl, rfl⟩
    refine ⟨⟨b, ?_⟩, rfl⟩
    rw [thetaLin_apply, theta]
    have hRb : br.flip b = 0 := by ext x; simpa using hb x
    rw [hRb, neg_zero]

theorem der1Sub_eq_map : der1Sub br = (lbiderSub br).map (LinearMap.fst R _ _) := rfl

theorem ilbiderSub_map_fst : (ilbiderSub br).map (LinearMap.fst R _ _) = innSub br := by
  rw [ilbiderSub, ← LinearMap.range_comp, innSub]
  have : (LinearMap.fst R _ _).comp (thetaLin br) = -br.flip := by
    ext a x; simp [thetaLin]
  rw [this, LinearMap.range_neg]

variable {K : Type*} [Field K] {V : Type*} [AddCommGroup V] [Module K V] [FiniteDimensional K V]
variable {brK : V →ₗ[K] V →ₗ[K] V}

/-- `dim LBider(L) = dim pr₁(LBider(L)) + dim ADer_0(L)`. -/
theorem finrank_lbider :
    finrank K (lbiderSub brK) = finrank K (der1Sub brK) + finrank K (ader0Sub brK) := by
  rw [← finrank_map_add_finrank_inf_ker (LinearMap.fst K _ _) (lbiderSub brK),
    lbiderSub_inf_ker_fst, der1Sub]
  congr 1
  exact (Submodule.equivMapOfInjective _ LinearMap.inr_injective _).finrank_eq.symm

/-- `dim ILBider(L) = dim Inn(L) + dim {L_b : b ∈ Ann_r(L)}`. -/
theorem finrank_ilbider :
    finrank K (ilbiderSub brK) = finrank K (innSub brK) + finrank K (cobSub brK) := by
  rw [← finrank_map_add_finrank_inf_ker (LinearMap.fst K _ _) (ilbiderSub brK),
    ilbiderSub_inf_ker_fst, ilbiderSub_map_fst]
  congr 1
  exact (Submodule.equivMapOfInjective _ LinearMap.inr_injective _).finrank_eq.symm

/-- **Dimension of the outer part.** In finite dimension,
`dim LBider(L) - dim ILBider(L) = (dim pr₁(LBider L) - dim Inn L) + dim H¹(L/Leib L, Ann_r L)`,
where `dim H¹ = dim ADer_0(L) - dim {L_b : b ∈ Ann_r(L)}`. -/
theorem finrank_outer (hL : IsRightLeibniz brK) :
    finrank K (lbiderSub brK) - finrank K (ilbiderSub brK) =
      (finrank K (der1Sub brK) - finrank K (innSub brK)) +
        (finrank K (ader0Sub brK) - finrank K (cobSub brK)) := by
  have h1 := Submodule.finrank_mono (innSub_le hL)
  have h2 := Submodule.finrank_mono (cobSub_le hL)
  rw [finrank_lbider, finrank_ilbider]
  omega

end Dimension

end LodayBider
