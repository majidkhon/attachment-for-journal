"""
Exact rational computations of derivations, Loday-antiderivations and
Loday-biderivations of finite-dimensional right Leibniz algebras.

An algebra of dimension m is given by structure constants
    C[(i, j)] = {k: c_ij^k}      meaning  [e_i, e_j] = sum_k c_ij^k e_k
(0-based indices).  Linear maps are m x m matrices M with M[p][i] the
coefficient of e_p in M(e_i).

All arithmetic is exact (fractions.Fraction).
"""
from fractions import Fraction as Fr
import itertools


# ---------------------------------------------------------------- linear algebra
def nullspace(rows, nvars):
    """rows: list of dict var->Fraction (each a homogeneous equation).
    Returns a basis of the solution space as a list of dense lists."""
    pivots = {}          # pivot var -> row (dict), fully reduced
    for r in rows:
        r = {k: v for k, v in r.items() if v != 0}
        for pv, pr in pivots.items():
            if pv in r:
                c = r[pv]
                for k, v in pr.items():
                    r[k] = r.get(k, 0) - c * v
                r = {k: v for k, v in r.items() if v != 0}
        if not r:
            continue
        pv = min(r)
        c = r[pv]
        r = {k: v / c for k, v in r.items()}
        for opv, opr in list(pivots.items()):
            if pv in opr:
                cc = opr[pv]
                for k, v in r.items():
                    opr[k] = opr.get(k, 0) - cc * v
                pivots[opv] = {k: v for k, v in opr.items() if v != 0}
        pivots[pv] = r
    free = [v for v in range(nvars) if v not in pivots]
    basis = []
    for f in free:
        vec = [Fr(0)] * nvars
        vec[f] = Fr(1)
        for pv, pr in pivots.items():
            vec[pv] = -pr.get(f, 0)
        basis.append(vec)
    return basis


def rank(vectors):
    if not vectors:
        return 0
    n = len(vectors[0])
    # rank = number of pivots of the row space
    rows = [{i: v for i, v in enumerate(vec) if v != 0} for vec in vectors]
    # transpose trick: rank of rows = n - dim{x : rows . x = 0}
    return n - len(nullspace(rows, n))


def solve_in_span(basis, target):
    """Coefficients x with sum x_i basis_i = target (basis linearly independent)."""
    nb = len(basis)
    n = len(target)
    rows = []
    for p in range(n):
        r = {i: basis[i][p] for i in range(nb) if basis[i][p] != 0}
        if target[p] != 0:
            r[nb] = -target[p]
        if r:
            rows.append(r)
    ns = nullspace(rows, nb + 1)
    for v in ns:
        if v[nb] != 0:
            return [x / v[nb] for x in v[:nb]]
    raise ValueError("target not in span")


# ---------------------------------------------------------------- algebras
class Algebra:
    def __init__(self, m, C, names=None):
        self.m = m
        self.C = {k: {kk: Fr(vv) for kk, vv in v.items() if vv != 0} for k, v in C.items()}
        self.C = {k: v for k, v in self.C.items() if v}
        self.names = names or [f"e{i+1}" for i in range(m)]

    def c(self, i, j, k):
        return self.C.get((i, j), {}).get(k, Fr(0))

    def mul(self, x, y):
        z = [Fr(0)] * self.m
        for i, xi in enumerate(x):
            if xi == 0:
                continue
            for j, yj in enumerate(y):
                if yj == 0:
                    continue
                for k, v in self.C.get((i, j), {}).items():
                    z[k] += xi * yj * v
        return z

    def unit(self, i):
        v = [Fr(0)] * self.m
        v[i] = Fr(1)
        return v

    def is_right_leibniz(self):
        m = self.m
        E = [self.unit(i) for i in range(m)]
        for x, y, z in itertools.product(range(m), repeat=3):
            lhs = self.mul(self.mul(E[x], E[y]), E[z])
            r1 = self.mul(self.mul(E[x], E[z]), E[y])
            r2 = self.mul(E[x], self.mul(E[y], E[z]))
            if any(lhs[k] != r1[k] + r2[k] for k in range(m)):
                return False
        return True

    # variables: d_{p,i} -> off + p*m+i
    def _der_rows(self, off, anti):
        m = self.m
        rows = []
        for i in range(m):
            for j in range(m):
                for k in range(m):
                    r = {}
                    for s, v in self.C.get((i, j), {}).items():
                        idx = off + k * m + s
                        r[idx] = r.get(idx, 0) + v
                    for p in range(m):
                        v = self.c(p, j, k)
                        if v:
                            idx = off + p * m + i
                            r[idx] = r.get(idx, 0) - v
                    if not anti:
                        for q in range(m):
                            v = self.c(i, q, k)
                            if v:
                                idx = off + q * m + j
                                r[idx] = r.get(idx, 0) - v
                    else:
                        for q in range(m):
                            v = self.c(q, i, k)
                            if v:
                                idx = off + q * m + j
                                r[idx] = r.get(idx, 0) + v
                    r = {a: b for a, b in r.items() if b != 0}
                    if r:
                        rows.append(r)
        return rows

    def _comp_rows(self):
        m = self.m
        rows = []
        for i in range(m):
            for j in range(m):
                for k in range(m):
                    r = {}
                    for q in range(m):
                        v = self.c(i, q, k)
                        if v:
                            r[q * m + j] = r.get(q * m + j, 0) + v
                            r[m * m + q * m + j] = r.get(m * m + q * m + j, 0) - v
                    r = {a: b for a, b in r.items() if b != 0}
                    if r:
                        rows.append(r)
        return rows

    def der(self):
        return nullspace(self._der_rows(0, False), self.m ** 2)

    def ader(self):
        return nullspace(self._der_rows(0, True), self.m ** 2)

    def bider(self):
        m = self.m
        rows = self._der_rows(0, False) + self._der_rows(m * m, True) + self._comp_rows()
        return nullspace(rows, 2 * m * m)

    def ann_l(self):
        m = self.m
        rows = []
        for j in range(m):
            for k in range(m):
                r = {i: self.c(i, j, k) for i in range(m) if self.c(i, j, k)}
                if r:
                    rows.append(r)
        return nullspace(rows, m)

    def ann_r(self):
        m = self.m
        rows = []
        for i in range(m):
            for k in range(m):
                r = {j: self.c(i, j, k) for j in range(m) if self.c(i, j, k)}
                if r:
                    rows.append(r)
        return nullspace(rows, m)

    def ann(self):
        m = self.m
        rows = []
        for a in range(m):
            for k in range(m):
                r = {i: self.c(i, a, k) for i in range(m) if self.c(i, a, k)}
                if r:
                    rows.append(r)
                r = {i: self.c(a, i, k) for i in range(m) if self.c(a, i, k)}
                if r:
                    rows.append(r)
        return nullspace(rows, m)

    def ader_into_annr(self):
        """Loday-antiderivations with values in Ann_r(L)."""
        m = self.m
        rows = self._der_rows(0, True)
        # values in Ann_r: [e_i, D(e_j)] = 0 for all i,j
        for i in range(m):
            for j in range(m):
                for k in range(m):
                    r = {}
                    for q in range(m):
                        v = self.c(i, q, k)
                        if v:
                            r[q * m + j] = r.get(q * m + j, 0) + v
                    if r:
                        rows.append(r)
        return nullspace(rows, m * m)


def mat_of(vec, m, off=0):
    return [[vec[off + p * m + i] for i in range(m)] for p in range(m)]


def mat_mul(A, B):
    m = len(A)
    return [[sum(A[p][q] * B[q][i] for q in range(m)) for i in range(m)] for p in range(m)]


def mat_sub(A, B):
    return [[A[p][i] - B[p][i] for i in range(len(A))] for p in range(len(A))]


def flat(A):
    return [A[p][i] for p in range(len(A)) for i in range(len(A))]


def bracket_pairs(v, w, m):
    d, D = mat_of(v, m), mat_of(v, m, m * m)
    d2, D2 = mat_of(w, m), mat_of(w, m, m * m)
    nd = mat_sub(mat_mul(d, d2), mat_mul(d2, d))
    nD = mat_sub(mat_mul(D, d2), mat_mul(d2, D))
    return flat(nd) + flat(nD)


def bider_algebra(L, basis=None):
    """Structure constants of LBider(L) w.r.t. the given (or computed) basis."""
    m = L.m
    B = basis if basis is not None else L.bider()
    N = len(B)
    C = {}
    for a in range(N):
        for b in range(N):
            vec = bracket_pairs(B[a], B[b], m)
            if any(vec):
                coeffs = solve_in_span(B, vec)
                C[(a, b)] = {k: v for k, v in enumerate(coeffs) if v != 0}
    return Algebra(N, C)


def theta(L, a):
    """Theta_a = (-R_a, L_a) as a flat vector of length 2 m^2."""
    m = L.m
    E = [L.unit(i) for i in range(m)]
    R = [[Fr(0)] * m for _ in range(m)]
    Lm = [[Fr(0)] * m for _ in range(m)]
    for i in range(m):
        r = L.mul(E[i], a)
        l = L.mul(a, E[i])
        for p in range(m):
            R[p][i] = -r[p]
            Lm[p][i] = l[p]
    return flat(R) + flat(Lm)


# ---------------------------------------------------------------- the algebras of the paper
def NF(n):
    C = {}
    for i in range(1, n):
        C[(i - 1, 0)] = {i: 1}
    return Algebra(n, C)


def F1(n):
    C = {(0, 0): {2: 1}}
    for i in range(2, n):
        C[(i - 1, 0)] = {i: 1}
    return Algebra(n, C)


def F2(n):
    C = {(0, 0): {2: 1}}
    for i in range(3, n):
        C[(i - 1, 0)] = {i: 1}
    return Algebra(n, C)


def R_alg(n):
    """basis e1..en (0..n-1), h (index n)"""
    h = n
    C = {}
    for i in range(1, n):
        C[(i - 1, 0)] = {i: 1}
    C[(h, 0)] = {0: -1}
    for i in range(1, n + 1):
        C[(i - 1, h)] = {i - 1: i}
    return Algebra(n + 1, C)


def RF1(n):
    """basis e1..en (0..n-1), h1 (n), h2 (n+1)   (adapted basis of the paper)"""
    h1, h2 = n, n + 1
    C = {}
    for i in range(2, n):
        C[(i - 1, 0)] = {i: 1}
    C[(0, h2)] = {0: 1}
    C[(h2, 0)] = {0: -1}
    for i in range(2, n + 1):
        C[(i - 1, h1)] = {i - 1: 1}
        C[(i - 1, h2)] = {i - 1: i - 1}
    return Algebra(n + 2, C)


def RF1_standard(n):
    """the same algebra in the basis f1=e1+e2, f2=e2, f_i=e_i (i>=3), same h1,h2"""
    h1, h2 = n, n + 1
    C = {(0, 0): {2: 1}}
    for i in range(2, n):
        C[(i - 1, 0)] = {i: 1}
    C[(0, h1)] = {1: 1}
    C[(0, h2)] = {0: 1}
    C[(h2, 0)] = {0: -1, 1: 1}
    for i in range(2, n + 1):
        C[(i - 1, h1)] = {i - 1: 1}
        C[(i - 1, h2)] = {i - 1: i - 1}
    return Algebra(n + 2, C)


def Lj(n, j):
    h1, h2 = n, n + 1
    C = {(0, 0): {2: 1}}
    for i in range(3, n):
        C[(i - 1, 0)] = {i: 1}
    C[(0, h2)] = {0: 1}
    C[(h2, 0)] = {0: -1}
    for i in range(3, n + 1):
        C[(i - 1, h2)] = {i - 1: i - 1}
    C[(1, h1)] = {1: 1}
    if j == 1:
        C[(h1, 1)] = {1: -1}
    return Algebra(n + 2, C)
