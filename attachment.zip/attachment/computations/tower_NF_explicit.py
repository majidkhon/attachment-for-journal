"""
Exact check of Theorem 7.3 (Loday-biderivation tower of NF_n) for 4 <= n <= maxn.

Starting from NF_n we build
  B0 = LBider(NF_n)            (basis X_1..X_n, Y_2..Y_n of Proposition 3.2),
  C0 = LBider(B0)              (basis Theta_a, a in B0, plus (P,P), (0,D'), (0,D'')),
  E0 = LBider(C0)              (basis Theta_a, a in C0, plus (T,0)),
and check:
  * the displayed elements are Loday-biderivations and form a basis of the full
    space of Loday-biderivations (so the dimensions are 2n-1, 2n+2, 2n+3);
  * the structure constants of C0 and E0 in these bases coincide with the
    multiplication tables (7.4) and (7.6) of the paper;
  * E0 is a fixed point: Ann(E0)=0, every derivation of E0 is inner, every
    Ann_r-valued Loday-antiderivation is a left multiplication, dim LBider(E0)=dim E0.
Usage: python3 tower_NF_explicit.py 8
"""
import sys
from fractions import Fraction as Fr
from bases import *


def table_C0(n):
    """Multiplication table (7.4) of C0 = LBider^2(NF_n)."""
    m = n - 1
    names = ['h'] + [f'x{j}' for j in range(1, m + 1)] + [f'y{j}' for j in range(1, m + 1)] + ['p', 'u', 'v']
    I = {s: i for i, s in enumerate(names)}
    C = {}

    def add(a, b, c, v):
        C.setdefault((I[a], I[b]), {})
        C[(I[a], I[b])][I[c]] = C[(I[a], I[b])].get(I[c], 0) + Fr(v)
    for j in range(1, m + 1):
        add('h', f'x{j}', f'x{j}', j); add('h', f'x{j}', f'y{j}', -1)
        add(f'x{j}', 'h', f'x{j}', -j); add(f'y{j}', 'h', f'y{j}', -j)
        add('u', f'x{j}', f'y{j}', 1)
        for i in range(1, m + 1):
            if i + j <= m:
                add(f'y{i}', f'x{j}', f'y{i+j}', -1)
    add('p', f'x{m}', f'x{m}', 1); add('p', f'x{m}', f'y{m}', Fr(-1, m))
    add(f'x{m}', 'p', f'x{m}', -1); add(f'x{m}', 'p', f'y{m}', Fr(1, m))
    add('v', f'x{m}', f'y{m}', 1); add('u', 'p', 'v', 1); add('v', 'p', 'v', 1)
    return Algebra(len(names), C, names)


def table_E0(n):
    """Multiplication table (7.6) of E0 = LBider^3(NF_n)."""
    A = table_C0(n); m = n - 1
    names = A.names + ['t']; I = {s: i for i, s in enumerate(names)}
    C = {k: dict(v) for k, v in A.C.items()}

    def add(a, b, c, v):
        C.setdefault((I[a], I[b]), {})
        C[(I[a], I[b])][I[c]] = C[(I[a], I[b])].get(I[c], 0) + Fr(v)
    add('h', 't', 'u', 1); add('h', 't', 'v', -1); add(f'x{m}', 't', f'y{m}', Fr(-1, m))
    for j in range(1, m + 1):
        add(f'y{j}', 't', f'y{j}', -1)
    add('u', 't', 'u', -1); add('v', 't', 'v', -1)
    return Algebra(len(names), C, names)


def same(A, B):
    return A.m == B.m and A.C == B.C


def mat(m, entries):
    M = [[Fr(0)] * m for _ in range(m)]
    for (p, i), c in entries.items():
        M[p][i] += Fr(c)
    return flat(M)


def check_full_basis(L, basis):
    full = L.bider()
    assert rank(basis) == len(basis), "not independent"
    assert rank(full + basis) == len(full), "not Loday-biderivations"
    assert len(full) == len(basis), "does not span"


def run(n):
    m = n - 1
    # step 1
    names0, Bas0 = NF_basis(n)
    N = NF(n)
    check_full_basis(N, Bas0)
    B0 = bider_algebra(N, Bas0)            # order: X1..Xn, Y2..Yn  = h, x1..xm, y1..ym
    k = B0.m                               # 2n-1
    E = [B0.unit(i) for i in range(k)]
    # step 2: Theta_a (a in B0) and (P,P),(0,D'),(0,D'')
    iX = lambda r: r - 1                   # X_r
    iY = lambda s: n + s - 2               # Y_s
    P = mat(k, {(iX(n), iX(n)): 1, (iY(n), iX(n)): Fr(-1, n - 1)})
    Dp = mat(k, {(iY(r), iX(r)): 1 for r in range(2, n + 1)})
    Dpp = mat(k, {(iY(n), iX(n)): 1})
    Z = [Fr(0)] * (k * k)
    Bas1 = [theta(B0, e) for e in E] + [P + P, Z + Dp, Z + Dpp]
    check_full_basis(B0, Bas1)
    C0 = bider_algebra(B0, Bas1)
    assert same(C0, table_C0(n)), "table (7.4) mismatch"
    # step 3: Theta_a (a in C0) and (T,0)
    A = table_C0(n); q = A.m; I = {s: i for i, s in enumerate(A.names)}
    ent = {(I['v'], I['h']): 1, (I['u'], I['h']): -1, (I[f'y{m}'], I[f'x{m}']): Fr(1, m)}
    for s in ['u', 'v'] + [f'y{j}' for j in range(1, m + 1)]:
        ent[(I[s], I[s])] = 1
    T = mat(q, ent)
    Bas2 = [theta(A, A.unit(i)) for i in range(q)] + [T + [Fr(0)] * (q * q)]
    check_full_basis(A, Bas2)
    E0 = bider_algebra(A, Bas2)
    assert same(E0, table_E0(n)), "table (7.6) mismatch"
    # fixed point
    F = table_E0(n)
    assert len(F.ann()) == 0
    assert len(F.der()) == F.m - len(F.ann_r())        # = dim Inn(E0)
    assert len(F.ader_into_annr()) == len(F.ann_r())   # = dim {L_b : b in Ann_r}
    assert len(F.bider()) == F.m
    return [N.m, B0.m, C0.m, E0.m, len(F.bider())]


if __name__ == '__main__':
    maxn = int(sys.argv[1]) if len(sys.argv) > 1 else 7
    for n in range(4, maxn + 1):
        print("n=%d dims of tower: %s  OK" % (n, run(n)), flush=True)
