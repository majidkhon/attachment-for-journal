import sys,time
from structure import *
maxn=int(sys.argv[1]); depth=int(sys.argv[2])
for n in range(4,maxn+1):
    for nm,L,bf in [("NF",NF(n),NF_basis),("F1",F1(n),F1_basis),("F2",F2(n),F2_basis)]:
        names,B=bf(n); A=bider_algebra(L,B)
        dims=[L.m,A.m]; t=time.time()
        cur=A
        for k in range(depth-1):
            Bk=cur.bider()
            dims.append(len(Bk))
            info=f"Ann={len(cur.ann())} Der={len(cur.der())} ADer={len(cur.ader())} A0={len(cur.ader_into_annr())} Annr={len(cur.ann_r())}"
            if k<depth-2: cur=bider_algebra(cur,Bk)
        print(n,nm,"dims of tower",dims,info,f"{time.time()-t:.1f}s",flush=True)
