import sys
from structure import *
n=int(sys.argv[1])
L=NF(n); names,B=NF_basis(n); A=bider_algebra(L,B)
m=A.m
Bb=A.bider()
inner=[theta(A,A.unit(i)) for i in range(m)]
print("dim",len(Bb),"inner rank",rank(inner))
# find complement of inner in Bb
comp=[]
cur=list(inner)
for v in Bb:
    if rank(cur+[v])>rank(cur):
        cur.append(v); comp.append(v)
def show(v):
    d=mat_of(v,m); D=mat_of(v,m,m*m)
    s=[]
    for i in range(m):
        di={names[p]:d[p][i] for p in range(m) if d[p][i]!=0}
        Di={names[p]:D[p][i] for p in range(m) if D[p][i]!=0}
        if di or Di: s.append(f"  {names[i]}: d->{di}  D->{Di}")
    print("\n".join(s))
# reduce comp modulo inner to make them sparse: just print
for v in comp:
    print("----"); show(v)
