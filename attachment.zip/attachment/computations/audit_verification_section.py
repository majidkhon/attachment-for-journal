"""Dimension audit for the computer-assisted verification section.

For 4 <= n <= 8 and each algebra of the paper, prints
dim Der, dim LADer, dim LADer_0, dim LBider, dim pr_1(LBider), rank of the
inner Loday-biderivations, dim Ann_r, dim Ann and dim H^1(g_L, Ann_r(L)).
All arithmetic is exact (fractions.Fraction).
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lbider import *

for n in range(4, 9):
    algs = [("NF_n", NF(n)), ("F_n^1", F1(n)), ("F_n^2", F2(n)), ("R", R_alg(n)),
            ("R(F_n^1)", RF1(n)), ("L_1", Lj(n, 1)), ("L_2", Lj(n, 2))]
    print("n =", n)
    for nm, L in algs:
        m = L.m
        B = L.bider()
        ar = L.ann_r()
        a0 = len(L.ader_into_annr())
        Lb = rank([theta(L, b)[m * m:] for b in ar]) if ar else 0
        print(f"  {nm:9s} dim={m:2d} Der={len(L.der()):2d} LADer={len(L.ader()):2d} "
              f"LADer0={a0:2d} LBider={len(B):2d} pr1={rank([v[:m*m] for v in B]):2d} "
              f"inner={rank([theta(L, L.unit(i)) for i in range(m)]):2d} "
              f"Ann_r={len(ar):2d} Ann={len(L.ann()):2d} H1={a0 - Lb:2d}")
