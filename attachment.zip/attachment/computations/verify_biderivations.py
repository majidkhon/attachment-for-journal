#!/usr/bin/env python3
"""
Supplementary code for the manuscript
  "Loday-biderivations and structural properties of filiform and solvable
   Leibniz algebras"  (M. Azizov, D. Jumaniyozov, B. Yusupov).

Pure Python 3 (standard library only); all arithmetic is exact (fractions).

For each algebra L given by structure constants [e_i,e_j] = sum_k c_ij^k e_k the
script solves the linear systems (8.1)-(8.3) of the paper for derivations,
Loday-antiderivations and Loday-biderivations, and then checks, for the listed
values of n, every explicit statement of Sections 3-7:

  * the dimensions of Der, LADer, LBider (table of Section 8);
  * that the explicit elements X_k, Y_k of Propositions 3.2, 3.5, 3.6 form a
    basis of LBider and that their brackets are exactly the printed tables;
  * the derived series, the nilradicals and their lower central series, the
    annihilators, the Leibniz kernels and the inner parts (Section 5),
    including the corrected descriptions of LIBider(NF_n) and LIBider(F_n^2);
  * the triangularity of right multiplications on Ann_r used in the proof of
    maximality of the nilradicals;
  * innerness of all Loday-biderivations of the solvable algebras (Section 4),
    the dimensions of Der and of ADer_0, the centralizers and the dimensions of
    the spaces of extendable Loday-biderivations (Section 6);
  * Proposition 7.2 and the (experimental) dimensions of the tower LBider^k.

Usage:  python3 verify_biderivations.py [nmin] [nmax] [tower_nmax]
Default: nmin=4, nmax=10, tower_nmax=7.
Every check raises AssertionError on failure; the script prints "ALL CHECKS
PASSED" at the end.
"""
import sys
from fractions import Fraction as Fr


# --------------------------------------------------------------------------
# Exact linear algebra
# --------------------------------------------------------------------------

def rref_rows(rows, nvars):
    """Gauss-Jordan elimination of sparse rows (dict var->coef).
    Returns dict pivot_var -> row (row normalized, pivot coefficient 1)."""
    pivots = {}
    for r in rows:
        r = {k: v for k, v in r.items() if v != 0}
        # reduce by existing pivots
        changed = True
        while r:
            # find a variable of r that is a pivot
            ks = [k for k in r if k in pivots]
            if not ks:
                break
            for k in ks:
                if k in r:
                    c = r[k]
                    for kk, vv in pivots[k].items():
                        nv = r.get(kk, 0) - c * vv
                        if nv == 0:
                            r.pop(kk, None)
                        else:
                            r[kk] = nv
        if not r:
            continue
        p = min(r)
        c = r[p]
        r = {k: v / c for k, v in r.items()}
        # eliminate p from the other pivot rows
        for q, row in pivots.items():
            if p in row:
                cc = row[p]
                for kk, vv in r.items():
                    nv = row.get(kk, 0) - cc * vv
                    if nv == 0:
                        row.pop(kk, None)
                    else:
                        row[kk] = nv
        pivots[p] = r
    return pivots


def nullspace(rows, nvars):
    """Basis of the solution space of the homogeneous system `rows`.
    Returns (basis, free) where basis[t] is a dense list and free[t] is the
    free variable equal to 1 in basis[t] (and 0 in the others)."""
    piv = rref_rows(rows, nvars)
    free = [v for v in range(nvars) if v not in piv]
    basis = []
    for f in free:
        vec = [Fr(0)] * nvars
        vec[f] = Fr(1)
        for p, row in piv.items():
            if f in row:
                vec[p] = -row[f]
        basis.append(vec)
    return basis, free


def rank(vectors):
    rows = [{i: v for i, v in enumerate(vec) if v != 0} for vec in vectors]
    if not rows:
        return 0
    return len(rref_rows(rows, len(vectors[0])))


def span_contains(basis_vecs, v):
    return rank(basis_vecs + [v]) == rank(basis_vecs)


def same_span(A, B):
    if not A and not B:
        return True
    ra = rank(A) if A else 0
    rb = rank(B) if B else 0
    return ra == rb == rank(A + B)


# --------------------------------------------------------------------------
# Leibniz algebras given by structure constants
# --------------------------------------------------------------------------

class Alg:
    """Algebra with basis 0..m-1 and bracket c[(i,j)] = {k: coef}."""

    def __init__(self, m, c, names=None):
        self.m = m
        self.c = {k: dict(v) for k, v in c.items() if v}
        self.names = names or [f"b{i}" for i in range(m)]

    def br(self, x, y):
        """bracket of coordinate vectors"""
        out = [Fr(0)] * self.m
        for i, xi in enumerate(x):
            if xi == 0:
                continue
            for j, yj in enumerate(y):
                if yj == 0:
                    continue
                for k, v in self.c.get((i, j), {}).items():
                    out[k] += xi * yj * v
        return out

    def unit(self, i):
        v = [Fr(0)] * self.m
        v[i] = Fr(1)
        return v

    def check_right_leibniz(self):
        m = self.m
        E = [self.unit(i) for i in range(m)]
        for i in range(m):
            for j in range(m):
                for k in range(m):
                    lhs = self.br(self.br(E[i], E[j]), E[k])
                    rhs = [a + b for a, b in zip(self.br(self.br(E[i], E[k]), E[j]),
                                                 self.br(E[i], self.br(E[j], E[k])))]
                    assert lhs == rhs, ("Leibniz identity fails", i, j, k)


def alg_from_table(m, table):
    """table: list of (i, j, {k: coef}) with 1-based indices."""
    c = {}
    for (i, j, img) in table:
        c[(i - 1, j - 1)] = {k - 1: Fr(v) for k, v in img.items()}
    return Alg(m, c)


# ---- matrices: dict (row, col) -> coef ; map e_col -> sum row coef e_row ----

def mat_apply(M, x, m):
    out = [Fr(0)] * m
    for (r, s), v in M.items():
        if x[s] != 0:
            out[r] += v * x[s]
    return out


def mat_mul(A, B):
    out = {}
    Bc = {}
    for (r, s), v in B.items():
        Bc.setdefault(r, []).append((s, v))
    for (i, r), v in A.items():
        for (s, w) in Bc.get(r, []):
            out[(i, s)] = out.get((i, s), 0) + v * w
    return {k: v for k, v in out.items() if v != 0}


def mat_sub(A, B):
    out = dict(A)
    for k, v in B.items():
        out[k] = out.get(k, 0) - v
    return {k: v for k, v in out.items() if v != 0}


def comm(A, B):
    return mat_sub(mat_mul(A, B), mat_mul(B, A))


def E(i, j, c=1):
    """matrix unit E_ij (1-based): e_j -> e_i"""
    return {(i - 1, j - 1): Fr(c)}


def msum(*Ms):
    out = {}
    for M in Ms:
        for k, v in M.items():
            out[k] = out.get(k, 0) + v
    return {k: v for k, v in out.items() if v != 0}


def mscale(c, M):
    return {k: c * v for k, v in M.items() if c * v != 0}


# --------------------------------------------------------------------------
# Equations (8.1)-(8.3)
# --------------------------------------------------------------------------

def var_d(p, i, m):  # coefficient d_{p i}: e_p-coordinate of d(e_i)
    return p * m + i


def var_D(p, i, m):
    return m * m + p * m + i


def bider_system(A, want="bider"):
    m = A.m
    c = A.c
    rows = []
    # derivation: d([e_i,e_j]) = [d e_i, e_j] + [e_i, d e_j]
    if want in ("bider", "der"):
        for i in range(m):
            for j in range(m):
                for k in range(m):
                    r = {}
                    for s, v in c.get((i, j), {}).items():
                        key = var_d(k, s, m)
                        r[key] = r.get(key, 0) + v
                    for p in range(m):
                        v = c.get((p, j), {}).get(k, 0)
                        if v:
                            key = var_d(p, i, m)
                            r[key] = r.get(key, 0) - v
                        v = c.get((i, p), {}).get(k, 0)
                        if v:
                            key = var_d(p, j, m)
                            r[key] = r.get(key, 0) - v
                    r = {a: b for a, b in r.items() if b != 0}
                    if r:
                        rows.append(r)
    # Loday-antiderivation: D([e_i,e_j]) = [D e_i, e_j] - [D e_j, e_i]
    if want in ("bider", "ader", "ader0"):
        for i in range(m):
            for j in range(m):
                for k in range(m):
                    r = {}
                    for s, v in c.get((i, j), {}).items():
                        key = var_D(k, s, m)
                        r[key] = r.get(key, 0) + v
                    for p in range(m):
                        v = c.get((p, j), {}).get(k, 0)
                        if v:
                            key = var_D(p, i, m)
                            r[key] = r.get(key, 0) - v
                        v = c.get((p, i), {}).get(k, 0)
                        if v:
                            key = var_D(p, j, m)
                            r[key] = r.get(key, 0) + v
                    r = {a: b for a, b in r.items() if b != 0}
                    if r:
                        rows.append(r)
    # compatibility: [e_i, (d-D) e_j] = 0
    if want == "bider":
        for i in range(m):
            for j in range(m):
                for k in range(m):
                    r = {}
                    for q in range(m):
                        v = c.get((i, q), {}).get(k, 0)
                        if v:
                            r[var_d(q, j, m)] = r.get(var_d(q, j, m), 0) + v
                            r[var_D(q, j, m)] = r.get(var_D(q, j, m), 0) - v
                    r = {a: b for a, b in r.items() if b != 0}
                    if r:
                        rows.append(r)
    if want == "der":
        for p in range(m):
            for i in range(m):
                rows.append({var_D(p, i, m): Fr(1)})
    if want in ("ader", "ader0"):
        for p in range(m):
            for i in range(m):
                rows.append({var_d(p, i, m): Fr(1)})
    if want == "ader0":
        # D(L) inside Ann_r(L): [e_i, D e_j] = 0
        for i in range(m):
            for j in range(m):
                for k in range(m):
                    r = {}
                    for q in range(m):
                        v = c.get((i, q), {}).get(k, 0)
                        if v:
                            r[var_D(q, j, m)] = r.get(var_D(q, j, m), 0) + v
                    if r:
                        rows.append(r)
    return rows


def vec_to_pair(vec, m):
    d = {}
    D = {}
    for p in range(m):
        for i in range(m):
            v = vec[var_d(p, i, m)]
            if v != 0:
                d[(p, i)] = v
            v = vec[var_D(p, i, m)]
            if v != 0:
                D[(p, i)] = v
    return d, D


def pair_to_vec(d, D, m):
    vec = [Fr(0)] * (2 * m * m)
    for (p, i), v in d.items():
        vec[var_d(p, i, m)] += v
    for (p, i), v in D.items():
        vec[var_D(p, i, m)] += v
    return vec


def space_dim(A, want):
    basis, _ = nullspace(bider_system(A, want), 2 * A.m * A.m)
    return len(basis)


def is_bider(A, d, D):
    m = A.m
    vec = pair_to_vec(d, D, m)
    for r in bider_system(A, "bider"):
        if sum(v * vec[k] for k, v in r.items()) != 0:
            return False
    return True


def bider_bracket(P, Q):
    (d, D), (d2, D2) = P, Q
    return (comm(d, d2), mat_sub(mat_mul(D, d2), mat_mul(d2, D)))


def inner(A, a):
    """Theta_a = (-R_a, L_a) as matrices"""
    m = A.m
    R = {}
    Lm = {}
    for i in range(m):
        ri = A.br(A.unit(i), a)
        li = A.br(a, A.unit(i))
        for p in range(m):
            if ri[p] != 0:
                R[(p, i)] = -ri[p]
            if li[p] != 0:
                Lm[(p, i)] = li[p]
    return R, Lm


def bider_algebra(A):
    """Leibniz algebra structure on LBider(A) in the nullspace basis."""
    m = A.m
    basis, free = nullspace(bider_system(A, "bider"), 2 * m * m)
    pairs = [vec_to_pair(v, m) for v in basis]
    N = len(pairs)
    c = {}
    for a in range(N):
        for b in range(N):
            d, D = bider_bracket(pairs[a], pairs[b])
            vec = pair_to_vec(d, D, m)
            coords = {t: vec[f] for t, f in enumerate(free) if vec[f] != 0}
            # sanity: vec equals sum coords*basis
            recon = [Fr(0)] * (2 * m * m)
            for t, v in coords.items():
                for k in range(2 * m * m):
                    if basis[t][k] != 0:
                        recon[k] += v * basis[t][k]
            assert recon == vec
            if coords:
                c[(a, b)] = coords
    return Alg(N, c), pairs


# --------------------------------------------------------------------------
# Generic structure computations on an algebra given in some basis
# --------------------------------------------------------------------------

def bracket_span(A, U, V):
    """span of [u, v] for u in U, v in V (lists of vectors)"""
    out = []
    for u in U:
        for v in V:
            w = A.br(u, v)
            if any(w):
                out.append(w)
    return reduce_basis(out, A.m)


def reduce_basis(vecs, m):
    if not vecs:
        return []
    piv = rref_rows([{i: v for i, v in enumerate(x) if v != 0} for x in vecs], m)
    out = []
    for p in sorted(piv):
        vec = [Fr(0)] * m
        for k, v in piv[p].items():
            vec[k] = v
        out.append(vec)
    return out


def ann_left(A):
    m = A.m
    rows = []
    for j in range(m):
        for k in range(m):
            r = {}
            for i in range(m):
                v = A.c.get((i, j), {}).get(k, 0)
                if v:
                    r[i] = v
            if r:
                rows.append(r)
    b, _ = nullspace(rows, m)
    return b


def ann_right(A):
    m = A.m
    rows = []
    for i in range(m):
        for k in range(m):
            r = {}
            for j in range(m):
                v = A.c.get((i, j), {}).get(k, 0)
                if v:
                    r[j] = v
            if r:
                rows.append(r)
    b, _ = nullspace(rows, m)
    return b


def leib(A):
    m = A.m
    E_ = [A.unit(i) for i in range(m)]
    out = []
    for i in range(m):
        for j in range(i, m):
            w = [a + b for a, b in zip(A.br(E_[i], E_[j]), A.br(E_[j], E_[i]))]
            if any(w):
                out.append(w)
    return reduce_basis(out, m)


def is_ideal(A, U):
    E_ = [A.unit(i) for i in range(A.m)]
    for u in U:
        for e in E_:
            if not span_contains(U, A.br(u, e)) or not span_contains(U, A.br(e, u)):
                return False
    return True


def lower_central(A, U, maxlen=100):
    """lower central series U^1=U, U^{k+1}=[U^k,U] (U a subalgebra)"""
    series = [reduce_basis(U, A.m)]
    while series[-1] and len(series) < maxlen:
        series.append(bracket_span(A, series[-1], U))
    return series


def derived(A, maxlen=100):
    E_ = [A.unit(i) for i in range(A.m)]
    series = [E_]
    while series[-1] and len(series) < maxlen:
        series.append(bracket_span(A, series[-1], series[-1]))
    return series


# --------------------------------------------------------------------------
# The algebras of the paper
# --------------------------------------------------------------------------

def NF(n):
    return alg_from_table(n, [(i, 1, {i + 1: 1}) for i in range(1, n)])


def F1(n):
    t = [(1, 1, {3: 1})] + [(i, 1, {i + 1: 1}) for i in range(2, n)]
    return alg_from_table(n, t)


def F2(n):
    t = [(1, 1, {3: 1})] + [(i, 1, {i + 1: 1}) for i in range(3, n)]
    return alg_from_table(n, t)


def R_alg(n):
    # basis e_1..e_n -> 1..n, h -> n+1
    h = n + 1
    t = [(i, 1, {i + 1: 1}) for i in range(1, n)]
    t += [(h, 1, {1: -1})]
    t += [(i, h, {i: i}) for i in range(1, n + 1)]
    return alg_from_table(n + 1, t)


def RF1(n):
    h1, h2 = n + 1, n + 2
    t = [(i, 1, {i + 1: 1}) for i in range(2, n)]
    t += [(1, h2, {1: 1}), (h2, 1, {1: -1})]
    t += [(i, h1, {i: 1}) for i in range(2, n + 1)]
    t += [(i, h2, {i: i - 1}) for i in range(2, n + 1)]
    return alg_from_table(n + 2, t)


def L12(n, which):
    h1, h2 = n + 1, n + 2
    t = [(1, 1, {3: 1})] + [(i, 1, {i + 1: 1}) for i in range(3, n)]
    t += [(1, h2, {1: 1}), (h2, 1, {1: -1})]
    t += [(i, h2, {i: i - 1}) for i in range(3, n + 1)]
    t += [(2, h1, {2: 1})]
    if which == 1:
        t += [(h1, 2, {2: -1})]
    return alg_from_table(n + 2, t)


# ---- explicit bases of the paper (Propositions 3.2, 3.5, 3.6) ----

def basis_NF(n):
    X = {}
    Y = {}
    X[1] = (msum(*[E(i, i, i) for i in range(1, n + 1)]), E(1, 1))
    for k in range(2, n + 1):
        X[k] = (msum(*[E(k + j, 1 + j) for j in range(0, n - k + 1)]), {})
        Y[k] = ({}, E(k, 1))
    return X, Y


def basis_F1(n):
    X = {}
    Y = {}
    X[1] = (msum(E(1, 1), E(2, 2), *[E(i, i, i - 1) for i in range(3, n + 1)]), E(1, 1))
    X[2] = (msum(E(2, 1), *[E(i, i) for i in range(2, n + 1)]), {})
    for k in range(3, n + 1):
        d = [E(k, 1)]
        if k <= n - 1:
            d.append(E(k, 2))
        # d(e_i) = sum_{l>i} a_{l-i+2} e_l, i>=3 : a_k contributes e_{i+k-2}
        for i in range(3, n + 1):
            if i + k - 2 <= n:
                d.append(E(i + k - 2, i))
        X[k] = (msum(*d), {})
    X[n + 1] = (E(n, 2), {})
    for k in range(2, n + 1):
        Y[k] = ({}, E(k, 1))
    Y[n + 1] = ({}, E(n, 2))
    return X, Y


def basis_F2(n):
    X = {}
    Y = {}
    X[1] = (msum(E(1, 1), *[E(i, i, i - 1) for i in range(3, n + 1)]), E(1, 1))
    X[2] = (E(2, 1), {})
    for k in range(3, n + 1):
        d = [E(k, 1)]
        for i in range(3, n + 1):
            if i + k - 2 <= n:
                d.append(E(i + k - 2, i))
        X[k] = (msum(*d), {})
    X[n + 1] = (E(2, 2), {})
    X[n + 2] = (E(n, 2), {})
    for k in range(2, n + 1):
        Y[k] = ({}, E(k, 1))
    Y[n + 1] = ({}, E(2, 2))
    Y[n + 2] = ({}, E(n, 2))
    return X, Y


# ---- the printed multiplication tables ----
# Each returns dict ((type,k),(type,l)) -> {(type,m): coef}, nonzero only.

def table_NF(n):
    T = {}

    def add(a, b, img):
        T[(a, b)] = {k: Fr(v) for k, v in img.items() if v != 0}
    for k in range(2, n + 1):
        add(('X', 1), ('X', k), {('X', k): k - 1, ('Y', k): -1})
        add(('X', k), ('X', 1), {('X', k): -(k - 1)})
        add(('Y', k), ('X', 1), {('Y', k): -(k - 1)})
        for l in range(2, n + 1):
            if k + l - 1 <= n:
                add(('Y', k), ('X', l), {('Y', k + l - 1): -1})
    return T


def table_F1(n):
    T = {}

    def add(a, b, img):
        T[(a, b)] = {k: Fr(v) for k, v in img.items() if v != 0}
    add(('X', 1), ('X', 2), {('Y', 2): -1})
    for k in range(3, n + 1):
        add(('X', 1), ('X', k), {('X', k): k - 2, ('Y', k): -1})
        add(('X', k), ('X', 1), {('X', k): -(k - 2)})
    add(('X', 1), ('X', n + 1), {('X', n + 1): n - 2})
    add(('X', n + 1), ('X', 1), {('X', n + 1): -(n - 2)})
    add(('X', 2), ('X', n), {('X', n): 1})
    add(('X', n), ('X', 2), {('X', n): -1})
    add(('X', 2), ('X', n + 1), {('X', n): -1})
    add(('X', n + 1), ('X', 2), {('X', n): 1})
    add(('Y', 2), ('X', 2), {('Y', 2): -1})
    for k in range(3, n):
        add(('Y', 2), ('X', k), {('Y', k): -1})
    add(('Y', 2), ('X', n + 1), {('Y', n): -1})
    for k in range(3, n + 1):
        add(('Y', k), ('X', 1), {('Y', k): -(k - 2)})
        add(('Y', k), ('X', 2), {('Y', k): -1})
    add(('Y', n + 1), ('X', 1), {('Y', n + 1): -(n - 2)})
    add(('Y', n + 1), ('X', 2), {('Y', n): 1})
    for k in range(3, n):
        for l in range(3, n):
            if k + l - 2 <= n:
                add(('Y', k), ('X', l), {('Y', k + l - 2): -1})
    return T


def table_F2(n):
    T = {}

    def add(a, b, img):
        T[(a, b)] = {k: Fr(v) for k, v in img.items() if v != 0}
    add(('X', 1), ('X', 2), {('X', 2): -1, ('Y', 2): -1})
    add(('X', 2), ('X', 1), {('X', 2): 1})
    for k in range(3, n + 1):
        add(('X', 1), ('X', k), {('X', k): k - 2, ('Y', k): -1})
        add(('X', k), ('X', 1), {('X', k): -(k - 2)})
    add(('X', 1), ('X', n + 2), {('X', n + 2): n - 1})
    add(('X', n + 2), ('X', 1), {('X', n + 2): -(n - 1)})
    add(('X', 2), ('X', n + 1), {('X', 2): -1})
    add(('X', n + 1), ('X', 2), {('X', 2): 1})
    add(('X', 2), ('X', n + 2), {('X', n): -1})
    add(('X', n + 2), ('X', 2), {('X', n): 1})
    add(('X', n + 1), ('X', n + 2), {('X', n + 2): -1})
    add(('X', n + 2), ('X', n + 1), {('X', n + 2): 1})
    add(('Y', 2), ('X', 1), {('Y', 2): 1})
    add(('Y', 2), ('X', n + 1), {('Y', 2): -1})
    add(('Y', 2), ('X', n + 2), {('Y', n): -1})
    for k in range(3, n + 1):
        add(('Y', k), ('X', 1), {('Y', k): -(k - 2)})
    for k in range(3, n):
        for l in range(3, n):
            if k + l - 2 <= n:
                add(('Y', k), ('X', l), {('Y', k + l - 2): -1})
    add(('Y', n + 1), ('X', 2), {('Y', 2): 1})
    add(('Y', n + 1), ('X', n + 2), {('Y', n + 2): -1})
    add(('Y', n + 2), ('X', 1), {('Y', n + 2): -(n - 1)})
    add(('Y', n + 2), ('X', 2), {('Y', n): 1})
    add(('Y', n + 2), ('X', n + 1), {('Y', n + 2): 1})
    return T


def labelled_algebra(A, X, Y):
    """Check that X,Y is a basis of LBider(A); return algebra in this basis."""
    m = A.m
    labels = [('X', k) for k in sorted(X)] + [('Y', k) for k in sorted(Y)]
    pairs = [X[k] for k in sorted(X)] + [Y[k] for k in sorted(Y)]
    for lab, P in zip(labels, pairs):
        assert is_bider(A, *P), ("not a biderivation", lab)
    vecs = [pair_to_vec(d, D, m) for d, D in pairs]
    assert rank(vecs) == len(vecs), "basis elements dependent"
    assert len(vecs) == space_dim(A, "bider"), "basis does not span"
    # coordinates of brackets
    N = len(pairs)
    # solve: express w as combination of vecs
    c = {}
    for a in range(N):
        for b in range(N):
            d, D = bider_bracket(pairs[a], pairs[b])
            w = pair_to_vec(d, D, m)
            coords = express(vecs, w)
            if coords:
                c[(a, b)] = coords
    return Alg(N, c), labels, pairs


def express(vecs, w):
    """coordinates of w in terms of the linearly independent list vecs"""
    if not any(w):
        return {}
    nv = len(vecs)
    L = len(w)
    rows = []
    for k in range(L):
        r = {t: vecs[t][k] for t in range(nv) if vecs[t][k] != 0}
        if w[k] != 0:
            r[nv] = -w[k]
        if r:
            rows.append(r)
    piv = rref_rows(rows, nv + 1)
    assert nv not in piv, "not in span"
    coords = {}
    for p, row in piv.items():
        val = -row.get(nv, 0)
        if val != 0:
            coords[p] = val
    # verify
    rec = [sum(coords.get(t, 0) * vecs[t][k] for t in range(nv)) for k in range(L)]
    assert rec == w
    return coords


def compare_table(B, labels, T):
    idx = {lab: i for i, lab in enumerate(labels)}
    for a in labels:
        for b in labels:
            got = B.c.get((idx[a], idx[b]), {})
            got = {labels[k]: v for k, v in got.items() if v != 0}
            exp = T.get((a, b), {})
            assert got == exp, ("table mismatch", a, b, got, exp)


def lab_vec(labels, items):
    """vector from dict label->coef"""
    v = [Fr(0)] * len(labels)
    idx = {lab: i for i, lab in enumerate(labels)}
    for lab, c in items.items():
        v[idx[lab]] += Fr(c)
    return v


def span_of(labels, labs):
    return [lab_vec(labels, {l: 1}) for l in labs]


# --------------------------------------------------------------------------
# Checks
# --------------------------------------------------------------------------

def check_nilpotent_case(n, name, A, X, Y, T, expect):
    A.check_right_leibniz()
    dims = (space_dim(A, "der"), space_dim(A, "ader"), space_dim(A, "bider"))
    assert dims == expect["dims"], (name, n, dims)
    B, labels, pairs = labelled_algebra(A, X, Y)
    compare_table(B, labels, T)
    B.check_right_leibniz()
    S = lambda labs: span_of(labels, labs)
    # derived series
    ds = derived(B)
    for k, labs in expect["derived"].items():
        assert same_span(ds[k - 1], S(labs)), (name, n, "derived", k)
    assert not ds[expect["solv_index"] - 1] and ds[expect["solv_index"] - 2]
    # nilradical: nilpotent ideal + lower central series
    Nlabs = expect["nilrad"]
    Nb = S(Nlabs)
    assert is_ideal(B, Nb)
    lcs = lower_central(B, Nb)
    for k, labs in expect["lcs"].items():
        assert same_span(lcs[k - 1], S(labs)) if labs else not lcs[k - 1], (name, n, "lcs", k)
    assert not lcs[expect["nil_index"] - 1] and lcs[expect["nil_index"] - 2]
    # annihilators and Leibniz kernel
    assert ann_left(B) == []
    assert same_span(ann_right(B), S(expect["ann_r"]))
    assert same_span(leib(B), S(expect["leib"]))
    # triangularity of right multiplications on Ann_r (maximality of N)
    order = expect["tri_order"]
    pos = {lab: i for i, lab in enumerate(order)}
    idx = {lab: i for i, lab in enumerate(labels)}
    for u in labels:
        uvec = lab_vec(labels, {u: 1})
        for y in order:
            img = B.br(lab_vec(labels, {y: 1}), uvec)
            for t, v in enumerate(img):
                if v != 0:
                    lt = labels[t]
                    assert lt in pos and pos[lt] >= pos[y], (name, n, "not triangular", u, y)
                    if lt == y and u in Nlabs:
                        raise AssertionError((name, n, "nonzero diagonal for nilradical element", u, y))
    # diagonal of R_u on Ann_r for u in the complement
    for u, diag in expect["diag"].items():
        uvec = lab_vec(labels, {u: 1})
        for y, val in diag.items():
            img = B.br(lab_vec(labels, {y: 1}), uvec)
            assert img[idx[y]] == val, (name, n, "diag", u, y, img[idx[y]], val)
    # inner part
    inner_vecs = []
    for i in range(A.m):
        d, D = inner(A, A.unit(i))
        w = pair_to_vec(d, D, A.m)
        inner_vecs.append(express([pair_to_vec(*p, A.m) for p in pairs], w))
    iv = [[c.get(t, Fr(0)) for t in range(len(labels))] for c in inner_vecs]
    for i, exp in expect["theta"].items():
        assert iv[i - 1] == lab_vec(labels, exp), (name, n, "theta", i, iv[i - 1])
    ivs = [v for v in iv if any(v)]
    assert same_span(ivs, [lab_vec(labels, e) for e in expect["libider"]])
    assert rank(ivs) == expect["libider_dim"]
    for lab in expect.get("not_inner", []):
        assert not span_contains(ivs, lab_vec(labels, {lab: 1})), (name, n, lab, "is inner?!")
    return B, labels, pairs


def nilpotent_checks(n):
    # ---- NF_n ----
    X, Y = basis_NF(n)
    Ys = [('Y', k) for k in range(2, n + 1)]
    Xs = [('X', k) for k in range(2, n + 1)]
    exp = dict(
        dims=(n, n, 2 * n - 1),
        derived={2: Xs + Ys, 3: [('Y', k) for k in range(3, n + 1)], 4: []},
        solv_index=4,
        nilrad=Xs + Ys,
        lcs={k: [('Y', j) for j in range(k + 1, n + 1)] for k in range(2, n + 1)},
        nil_index=n,
        ann_r=Ys, leib=Ys,
        tri_order=[('Y', k) for k in range(2, n + 1)],
        diag={('X', 1): {('Y', k): -(k - 1) for k in range(2, n + 1)}},
        theta=dict([(1, {('Y', 2): 1, ('X', 2): -1})] +
                   [(i, {('Y', i + 1): 1}) for i in range(2, n)] + [(n, {})]),
        libider=[{('Y', 2): 1, ('X', 2): -1}] + [{('Y', k): 1} for k in range(3, n + 1)],
        libider_dim=n - 1,
        not_inner=[('X', 2)],
    )
    exp["derived"].pop(4)
    B0, lab0, pairs0 = check_nilpotent_case(n, "NF", NF(n), X, Y, table_NF(n), exp)
    # ---- F_n^1 ----
    X, Y = basis_F1(n)
    N1 = [('X', k) for k in range(3, n + 2)] + [('Y', k) for k in range(2, n + 2)]
    exp = dict(
        dims=(n + 1, n + 2, 2 * n + 1),
        derived={2: N1, 3: [('Y', k) for k in range(3, n + 1)]},
        solv_index=4,
        nilrad=N1,
        lcs={k: [('Y', j) for j in range(k + 1, n + 1)] for k in range(2, n + 1)},
        nil_index=n,
        ann_r=[('Y', k) for k in range(2, n + 2)],
        leib=[('Y', k) for k in range(2, n + 2)],
        tri_order=[('Y', k) for k in range(2, n)] + [('Y', n + 1), ('Y', n)],
        diag={('X', 1): dict([(('Y', 2), 0)] + [(('Y', k), -(k - 2)) for k in range(3, n + 1)]
                             + [(('Y', n + 1), -(n - 2))]),
              ('X', 2): dict([(('Y', k), -1) for k in range(2, n + 1)] + [(('Y', n + 1), 0)])},
        theta=dict([(1, {('Y', 3): 1, ('X', 3): -1}), (2, {('Y', 3): 1})] +
                   [(i, {('Y', i + 1): 1}) for i in range(3, n)] + [(n, {})]),
        libider=[{('X', 3): 1}] + [{('Y', k): 1} for k in range(3, n + 1)],
        libider_dim=n - 1,
    )
    check_nilpotent_case(n, "F1", F1(n), X, Y, table_F1(n), exp)
    # ---- F_n^2 ----
    X, Y = basis_F2(n)
    D2 = [('X', k) for k in range(2, n + 1)] + [('X', n + 2)] + \
         [('Y', k) for k in range(2, n + 1)] + [('Y', n + 2)]
    N2 = D2 + [('Y', n + 1)]
    lcs = {2: [('X', n), ('Y', 2)] + [('Y', k) for k in range(4, n + 1)] + [('Y', n + 2)]}
    if n >= 5:
        for k in range(3, n):
            lcs[k] = [('Y', j) for j in range(k + 2, n + 1)]
        nil_index = n - 1
    else:
        lcs[3] = [('Y', 4)]
        lcs[4] = []
        nil_index = 4
    exp = dict(
        dims=(n + 2, n + 2, 2 * n + 3),
        derived={2: D2, 3: [('X', n)] + [('Y', k) for k in range(4, n + 1)]},
        solv_index=4,
        nilrad=N2,
        lcs=lcs,
        nil_index=nil_index,
        ann_r=[('Y', k) for k in range(2, n + 3)],
        leib=[('Y', k) for k in range(2, n + 1)] + [('Y', n + 2)],
        tri_order=[('Y', n + 1), ('Y', 2), ('Y', n + 2)] + [('Y', k) for k in range(3, n + 1)],
        diag={('X', 1): dict([(('Y', 2), 1), (('Y', n + 1), 0), (('Y', n + 2), -(n - 1))]
                             + [(('Y', k), -(k - 2)) for k in range(3, n + 1)]),
              ('X', n + 1): dict([(('Y', 2), -1), (('Y', n + 1), 0), (('Y', n + 2), 1)]
                                 + [(('Y', k), 0) for k in range(3, n + 1)])},
        theta=dict([(1, {('Y', 3): 1, ('X', 3): -1}), (2, {})] +
                   [(i, {('Y', i + 1): 1}) for i in range(3, n)] + [(n, {})]),
        libider=[{('Y', 3): 1, ('X', 3): -1}] + [{('Y', k): 1} for k in range(4, n + 1)],
        libider_dim=n - 2,
        not_inner=[('X', 3)],
    )
    check_nilpotent_case(n, "F2", F2(n), X, Y, table_F2(n), exp)
    return B0, lab0


def solvable_checks(n):
    cases = [
        ("R", R_alg(n), 2, n + 1, n + 1, n - 1, [n], 1),
        ("R(F1)", RF1(n), 3, n + 3, n + 2, n - 1, [n], 2),
        ("L1", L12(n, 1), 4, n + 2, n + 2, n - 2, [2, n], 2),
        ("L2", L12(n, 2), 3, n + 3, n + 2, n - 1, [2, n], 2),
    ]
    for name, S, dder, dader, dbider, dader0, cent, dimQ in cases:
        S.check_right_leibniz()
        m = S.m
        assert space_dim(S, "der") == dder, (name, n)
        assert space_dim(S, "ader") == dader, (name, n)
        assert space_dim(S, "bider") == dbider == m, (name, n)
        # ADer_0 = {L_b : b in Ann_r}
        ar = ann_right(S)
        assert space_dim(S, "ader0") == dader0 == len(ar), (name, n)
        # all derivations are inner: Der = {R_a}
        Rs = []
        for i in range(m):
            d, _ = inner(S, S.unit(i))
            Rs.append(pair_to_vec(d, {}, m))
        assert rank([v for v in Rs if any(v)]) == dder, (name, n, "Der not inner")
        # all biderivations inner: inner family has rank dim S = dim LBider
        Th = [pair_to_vec(*inner(S, S.unit(i)), m) for i in range(m)]
        assert rank(Th) == m, (name, n)
        # nilradical N = span(e_1..e_n): nilpotent ideal
        Nb = [S.unit(i) for i in range(n)]
        assert is_ideal(S, Nb)
        lcs = lower_central(S, Nb)
        assert not lcs[-1]
        # derived series: S^[2]=N, S^[3], S^[4]=0  (table of Theorem 5.4)
        ds = derived(S)
        assert same_span(ds[1], Nb) and ds[2] and not ds[3], (name, n)
        U = lambda idxs: [S.unit(i - 1) for i in idxs]
        s3 = {"R": range(2, n + 1)}.get(name, range(3, n + 1))
        assert same_span(ds[2], U(s3)), (name, n, "S^[3]")
        annl = {"R": [], "R(F1)": [n + 1], "L1": [], "L2": [n + 1]}[name]
        assert same_span(ann_left(S), U(annl)), (name, n, "Ann_l")
        annr = {"L1": range(3, n + 1)}.get(name, range(2, n + 1))
        assert same_span(ann_right(S), U(annr)), (name, n, "Ann_r")
        assert same_span(leib(S), U(annr)), (name, n, "Leib")
        # centralizer C_S(N)
        rows = []
        for i in range(n):
            for k in range(m):
                r1 = {j: S.c.get((i, j), {}).get(k, 0) for j in range(m)}
                r1 = {a: b for a, b in r1.items() if b != 0}
                r2 = {j: S.c.get((j, i), {}).get(k, 0) for j in range(m)}
                r2 = {a: b for a, b in r2.items() if b != 0}
                for r in (r1, r2):
                    if r:
                        rows.append(r)
        C, _ = nullspace(rows, m)
        assert same_span(C, [S.unit(i - 1) for i in cent]), (name, n, "centralizer")
        # extendable biderivations: restrictions of inner biderivations to N
        N_alg = Alg(n, {(i, j): {k: v for k, v in S.c.get((i, j), {}).items()}
                        for i in range(n) for j in range(n) if S.c.get((i, j))})
        for kk, vv in list(N_alg.c.items()):
            assert all(k < n for k in vv)
        restr = []
        for i in range(m):
            d, D = inner(S, S.unit(i))
            dr = {(p, q): v for (p, q), v in d.items() if q < n}
            Dr = {(p, q): v for (p, q), v in D.items() if q < n}
            assert all(p < n for (p, q) in dr) and all(p < n for (p, q) in Dr)
            assert is_bider(N_alg, dr, Dr)
            restr.append(pair_to_vec(dr, Dr, n))
        dimE = rank([v for v in restr if any(v)])
        dimBN = space_dim(N_alg, "bider")
        expect_E = {"R": n, "R(F1)": n + 1, "L1": n, "L2": n}[name]
        assert dimE == expect_E, (name, n, dimE)
        assert dimBN - dimE == {"R": n - 1, "R(F1)": n, "L1": n + 3, "L2": n + 3}[name]


def prop72_check(n, B0, lab0):
    """Proposition 7.2: (P,P), (0,D'), (0,D'') are Loday-biderivations of B_0"""
    N = B0.m
    idx = {lab: i for i, lab in enumerate(lab0)}
    P = {(idx[('X', n)], idx[('X', n)]): Fr(1), (idx[('Y', n)], idx[('X', n)]): Fr(-1, n - 1)}
    Dp = {(idx[('Y', k)], idx[('X', k)]): Fr(1) for k in range(2, n + 1)}
    Dpp = {(idx[('Y', n)], idx[('X', n)]): Fr(1)}
    for pair in [(P, P), ({}, Dp), ({}, Dpp)]:
        assert is_bider(B0, *pair)
    Th = [pair_to_vec(*inner(B0, B0.unit(i)), N) for i in range(N)]
    extra = [pair_to_vec(P, P, N), pair_to_vec({}, Dp, N), pair_to_vec({}, Dpp, N)]
    assert rank(Th + extra) == 2 * n + 2
    return rank(Th + extra)



# --------------------------------------------------------------------------
# General bracket formulas (Lemmas 3.3, 3.6, 3.9 of the revised manuscript)
# --------------------------------------------------------------------------

def pair_NF(n, al, be):
    """(d,D) of Theorem 3.1; al[1..n], be[2..n]"""
    d = {}
    for i in range(1, n + 1):
        d[(i - 1, i - 1)] = d.get((i - 1, i - 1), 0) + i * al[1]
        for j in range(i + 1, n + 1):
            d[(j - 1, i - 1)] = d.get((j - 1, i - 1), 0) + al[j - i + 1]
    D = {(0, 0): al[1]}
    for j in range(2, n + 1):
        D[(j - 1, 0)] = be[j]
    return d, D


def pair_F1(n, a, b):
    d = {}

    def add(M, r, c, v):
        M[(r - 1, c - 1)] = M.get((r - 1, c - 1), 0) + v
    for k in range(1, n + 1):
        add(d, k, 1, a[k])
    add(d, 2, 2, a[1] + a[2])
    for k in range(3, n):
        add(d, k, 2, a[k])
    add(d, n, 2, a[n + 1])
    for i in range(3, n + 1):
        add(d, i, i, (i - 1) * a[1] + a[2])
        for k in range(i + 1, n + 1):
            add(d, k, i, a[k - i + 2])
    D = {}
    add(D, 1, 1, a[1])
    for j in range(2, n + 1):
        add(D, j, 1, b[j])
    add(D, n, 2, b[n + 1])
    return d, D


def pair_F2(n, a, b):
    d = {}

    def add(M, r, c, v):
        M[(r - 1, c - 1)] = M.get((r - 1, c - 1), 0) + v
    for k in range(1, n + 1):
        add(d, k, 1, a[k])
    add(d, 2, 2, a[n + 1])
    add(d, n, 2, a[n + 2])
    for i in range(3, n + 1):
        add(d, i, i, (i - 1) * a[1])
        for k in range(i + 1, n + 1):
            add(d, k, i, a[k - i + 2])
    D = {}
    add(D, 1, 1, a[1])
    for j in range(2, n + 1):
        add(D, j, 1, b[j])
    add(D, 2, 2, b[n + 1])
    add(D, n, 2, b[n + 2])
    return d, D


def formula_NF(n, al, be, al2, be2):
    A = {1: 0}
    B = {}
    for k in range(2, n + 1):
        A[k] = (k - 1) * (al[1] * al2[k] - al2[1] * al[k])
        B[k] = -(k - 1) * al2[1] * be[k] - al[1] * al2[k] - sum(be[j] * al2[k - j + 1] for j in range(2, k))
    return A, B


def formula_F1(n, a, b, a2, b2):
    A = {1: 0, 2: 0}
    B = {}
    for k in range(3, n):
        A[k] = (k - 2) * (a[1] * a2[k] - a2[1] * a[k])
    A[n] = (n - 2) * (a[1] * a2[n] - a2[1] * a[n]) + (a[2] * a2[n] - a2[2] * a[n]) + (a2[2] * a[n + 1] - a[2] * a2[n + 1])
    A[n + 1] = (n - 2) * (a[1] * a2[n + 1] - a2[1] * a[n + 1])
    B[2] = -a2[2] * (a[1] + b[2])
    for k in range(3, n):
        B[k] = -(k - 2) * a2[1] * b[k] - a2[2] * b[k] - (a[1] + b[2]) * a2[k] - sum(b[j] * a2[k - j + 2] for j in range(3, k))
    B[n] = (-(n - 2) * a2[1] * b[n] - a2[2] * b[n] + a2[2] * b[n + 1] - a[1] * a2[n] - b[2] * a2[n + 1]
            - sum(b[j] * a2[n - j + 2] for j in range(3, n)))
    B[n + 1] = -(n - 2) * a2[1] * b[n + 1]
    return A, B


def formula_F2(n, a, b, a2, b2):
    A = {1: 0}
    B = {}
    A[2] = a[2] * (a2[1] - a2[n + 1]) - a2[2] * (a[1] - a[n + 1])
    for k in range(3, n):
        A[k] = (k - 2) * (a[1] * a2[k] - a2[1] * a[k])
    A[n] = (n - 2) * (a[1] * a2[n] - a2[1] * a[n]) + a2[2] * a[n + 2] - a[2] * a2[n + 2]
    A[n + 1] = 0
    A[n + 2] = (n - 1) * (a[1] * a2[n + 2] - a2[1] * a[n + 2]) + a2[n + 1] * a[n + 2] - a[n + 1] * a2[n + 2]
    B[2] = b[2] * (a2[1] - a2[n + 1]) + a2[2] * (b[n + 1] - a[1])
    for k in range(3, n):
        B[k] = -(k - 2) * a2[1] * b[k] - a[1] * a2[k] - sum(b[j] * a2[k - j + 2] for j in range(3, k))
    B[n] = (-(n - 2) * a2[1] * b[n] - a[1] * a2[n] + a2[2] * b[n + 2] - b[2] * a2[n + 2]
            - sum(b[j] * a2[n - j + 2] for j in range(3, n)))
    B[n + 1] = 0
    B[n + 2] = (a2[n + 1] - (n - 1) * a2[1]) * b[n + 2] - a2[n + 2] * b[n + 1]
    return A, B


def check_bracket_formulas(n, trials=5):
    import random
    rnd = random.Random(n)
    R = lambda: Fr(rnd.randint(-9, 9), rnd.randint(1, 5))
    for builder, formula, alg, na, bmax in [(pair_NF, formula_NF, NF(n), n, n),
                                            (pair_F1, formula_F1, F1(n), n + 1, n + 1),
                                            (pair_F2, formula_F2, F2(n), n + 2, n + 2)]:
        for _ in range(trials):
            a = {k: R() for k in range(1, na + 1)}
            b = {k: R() for k in range(2, bmax + 1)}
            a2 = {k: R() for k in range(1, na + 1)}
            b2 = {k: R() for k in range(2, bmax + 1)}
            P = builder(n, a, b)
            Q = builder(n, a2, b2)
            assert is_bider(alg, *P) and is_bider(alg, *Q)
            br = bider_bracket(P, Q)
            A, B = formula(n, a, b, a2, b2)
            expect = builder(n, A, B)
            assert pair_to_vec(*br, n) == pair_to_vec(*expect, n), (builder.__name__, n)


def outer_B1_B2_check(n):
    """Proposition 7.3: (0,D_1) in LBider(B_1) and (0,D_2) in LBider(B_2) are not inner"""
    for builder, A, ks in [(basis_F1, F1(n), range(2, n + 1)), (basis_F2, F2(n), range(3, n))]:
        X, Y = builder(n)
        B, lab, _ = labelled_algebra(A, X, Y)
        idx = {l: i for i, l in enumerate(lab)}
        D = {(idx[('Y', k)], idx[('X', k)]): Fr(1) for k in ks}
        assert is_bider(B, {}, D)
        Th = [pair_to_vec(*inner(B, B.unit(i)), B.m) for i in range(B.m)]
        assert not span_contains(Th, pair_to_vec({}, D, B.m))


def main():
    nmin = int(sys.argv[1]) if len(sys.argv) > 1 else 4
    nmax = int(sys.argv[2]) if len(sys.argv) > 2 else 10
    tmax = int(sys.argv[3]) if len(sys.argv) > 3 else 7
    for n in range(nmin, nmax + 1):
        B0, lab0 = nilpotent_checks(n)
        solvable_checks(n)
        prop72_check(n, B0, lab0)
        check_bracket_formulas(n)
        outer_B1_B2_check(n)
        print(f"n={n}: statements of Sections 3-7 verified")
    for n in range(2, 4):
        assert space_dim(NF(n), "bider") == 2 * n - 1
    # Section 7 (experimental): the tower LBider^k(N), k <= 4
    expected = {"NF": lambda n: [n, 2 * n - 1, 2 * n + 2, 2 * n + 3, 2 * n + 3],
                "F1": lambda n: [n, 2 * n + 1, 2 * n + 4, 2 * n + 6, 2 * n + 6],
                "F2": lambda n: [n, 2 * n + 3, 2 * n + 6, 2 * n + 7, 2 * n + 7]}
    for n in range(nmin, tmax + 1):
        for name, A in [("NF", NF(n)), ("F1", F1(n)), ("F2", F2(n))]:
            dims = [A.m]
            cur = A
            for k in range(4):
                cur, _ = bider_algebra(cur)
                dims.append(cur.m)
                if k == 2:
                    # LBider^3(N) has zero annihilator
                    al, ar = ann_left(cur), ann_right(cur)
                    both = al and ar and rank(al) + rank(ar) > rank(al + ar)
                    assert not both, (name, n, "Ann(LBider^3) != 0")
            assert dims == expected[name](n), (name, n, dims)
            print(f"n={n} {name}: dim LBider^k(N), k=0..4: {dims}")
        # Proposition 7.2 elements + inner span all of LBider(B_0)
        B0, _ = bider_algebra(NF(n))
        assert space_dim(B0, "bider") == 2 * n + 2
    # dim LBider^2(NF_8) = 18 (Proposition 7.2 elements + inner part span it)
    B0, _ = bider_algebra(NF(8))
    assert space_dim(B0, "bider") == 18
    print("ALL CHECKS PASSED")


if __name__ == "__main__":
    main()
