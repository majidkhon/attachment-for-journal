from lbider import *
for n in range(4,9):
    algs = [("NF",NF(n)),("F1",F1(n)),("F2",F2(n)),("R",R_alg(n)),("RF1",RF1(n)),("RF1std",RF1_standard(n)),("L1",Lj(n,1)),("L2",Lj(n,2))]
    out=[]
    for nm,A in algs:
        assert A.is_right_leibniz(), nm
        B=A.bider()
        th=[theta(A,A.unit(i)) for i in range(A.m)]
        out.append(f"{nm}: Der {len(A.der())} ADer {len(A.ader())} Bid {len(B)} inner {rank(th)} Annl {len(A.ann_l())} Annr {len(A.ann_r())} Ann {len(A.ann())} A0 {len(A.ader_into_annr())}")
    print(n); print("\n".join(out))
